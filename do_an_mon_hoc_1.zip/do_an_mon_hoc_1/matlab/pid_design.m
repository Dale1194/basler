%% ========================================================================
% pid_design.m
% Thiet ke bo PID vi tri cho he truyen dong dien - ban truot tuyen tinh
%
% Phuong phap:
%   1. P controller (P-only): don gian, SSE = 0 cho step (Type 1 plant)
%   2. PI controller: tang cuong kha nang khang nhieu
%   3. PID controller: toi uu dap ung qua do, them Kd de giam overshoot
%
% Tieu chi thiet ke:
%   - Sai so vi tri on dinh:  <= 0.5 mm (yeu cau)
%   - Thoi gian qua do (settling 2%): < 1.0 s
%   - Overshoot: < 10%
%   - Gain margin: > 10 dB
%   - Phase margin: > 45 deg
%
% Luu y: Chay param_calc.m va plant_model.m truoc.
% =========================================================================

clc; clear; close all;

if ~exist('params.mat', 'file') || ~exist('plant.mat', 'file')
    error('Hay chay param_calc.m va plant_model.m truoc!');
end
load('params.mat');
load('plant.mat');

fprintf('\n========================================================================\n');
fprintf('  THIET KE BO PID VI TRI\n');
fprintf('========================================================================\n\n');

% Lay mo hinh tu file
P = G_position;       % P(s) = X(s)/V_a(s)
K = K_final;          % he so vi tri (m/(V.s))
tau = tau_final;      % hang so thoi gian (s)

fprintf('  Plant: P(s) = %.4f / [s*(%.4f s + 1)]\n', K, tau);
fprintf('  (Type 1 system, he so K = %.4f, tau_v = %.3f ms)\n\n', K, tau*1000);

%% ====================== 1. BO P (PROPORTIONAL) =========================
fprintf('--- 1. BO DIEU KHIEN TI LE (P-ONLY) ---\n\n');

% P controller: C(s) = Kp
% Open-loop: L(s) = Kp*K / [s*(tau*s + 1)]
% Closed-loop characteristic: tau*s^2 + s + Kp*K = 0
% => s^2 + (1/tau)*s + (Kp*K/tau) = 0
% Standard form: s^2 + 2*zeta*omega_n*s + omega_n^2 = 0
% => omega_n = sqrt(Kp*K/tau)
% => 2*zeta*omega_n = 1/tau  =>  omega_n = 1/(2*zeta*tau)

% Chon he so damping ζ:
zeta_P = 1.0;    % Critically damped (zero overshoot)
omega_n_P = 1 / (2 * zeta_P * tau);   % rad/s
Kp_P = omega_n_P^2 * tau / K;

fprintf('  Chon ζ = %.2f (critically damped - khong overshoot)\n', zeta_P);
fprintf('  omega_n (closed-loop) = %.2f rad/s\n', omega_n_P);
fprintf('  Kp = omega_n^2 * tau / K = %.2f V/m\n\n', Kp_P);

% Kiem tra dat yeu cau
SSE_P_theoretical = 0;   % Type 1 + P = Type 1, SSE_step = 0
fprintf('  Sai so on dinh ly thuyet (step input): %.4f mm\n', SSE_P_theoretical*1000);
fprintf('  Thoi gian qua do (2%%): 4/(ζ·ω_n) = %.0f ms\n', 4/(zeta_P*omega_n_P)*1000);
fprintf('  Rise time (10%%-90%%): ~1.8/ω_n = %.0f ms\n\n', 1.8/omega_n_P*1000);

% Nhan xet:
fprintf('  Nhan xet:\n');
fprintf('    - ω_n rat lon (%.0f rad/s) do plant rat nhanh (τ = %.1f ms).\n', ...
        omega_n_P, tau*1000);
fprintf('    - Kp rat lon (%.0f V/m), vi the he thong se saturation khi\n', Kp_P);
fprintf('      error lon (vi du khi buoc lenh 300 mm, error = 0.3 m => Kp*e = %.0f V).\n', ...
        Kp_P * 0.3);
fprintf('    - Can co saturation va anti-windup trong thuc te.\n\n');

%% ====================== 2. BO PI (PROPORTIONAL-INTEGRAL) ================
fprintf('--- 2. BO DIEU KHIEN PI (P + I) ---\n\n');

% PI controller: C(s) = Kp + Ki/s = (Kp*s + Ki)/s
% Open-loop: L(s) = (Kp + Ki/s) * K / [s*(tau*s + 1)]
% Closed-loop char.: tau*s^3 + s^2 + K*Kp*s + K*Ki = 0
% Sau khi chia cho tau: s^3 + (1/tau)*s^2 + (K*Kp/tau)*s + K*Ki/tau = 0
%
% Thiet ke bang pole placement:
% Dat cac closed-loop pole tai:
%   s1,2 = -ζω_n ± jω_n*sqrt(1-ζ²)  (cap dominant)
%   s3   = -α (pole them tu I action)
%
% (s^2 + 2ζω_n*s + ω_n^2)(s + α) = s^3 + (2ζω_n + α)s^2 + (ω_n^2 + 2ζω_n*α)s + ω_n^2*α
%
% So sanh voi he so cua closed-loop char.:
%   2ζω_n + α = 1/tau
%   ω_n^2 + 2ζω_n*α = K*Kp/tau
%   ω_n^2*α = K*Ki/tau

% Chon thong so:
zeta_PI = 1.0;          % Damping ratio
omega_n_PI = 30;        % rad/s (chon thap hon de on dinh, tranh saturation)

alpha_PI = 1/tau - 2*zeta_PI*omega_n_PI;
if alpha_PI <= 0
    error('alpha_PI phai > 0. Hay giam ω_n hoac ζ.');
end

% Tinh Kp, Ki
Kp_PI = (tau/K) * (omega_n_PI^2 + 2*zeta_PI*omega_n_PI*alpha_PI);
Ki_PI = (tau/K) * omega_n_PI^2 * alpha_PI;

% Tinh Kp theo don vi de hien thi
Kp_PI_disp = Kp_PI;
Ki_PI_disp = Ki_PI;

fprintf('  Chon ζ = %.2f, ω_n = %.0f rad/s (dat cach he thong Type 1)\n', zeta_PI, omega_n_PI);
fprintf('  α (pole phu) = %.2f rad/s\n', alpha_PI);
fprintf('  Kp = %.2f V/m\n', Kp_PI_disp);
fprintf('  Ki = %.2f V/(m·s)\n\n', Ki_PI_disp);

% Thoi gian dap ung du kien
settling_PI = 4/(zeta_PI*omega_n_PI);
fprintf('  Thoi gian qua do (2%%) uoc tinh: ~%.0f ms\n', settling_PI*1000);
fprintf('  Sai so on dinh ly thuyet (step): 0 (Type 2)\n');
fprintf('  Sai so on dinh (ramp 0.2 m/s): %.2f mm (SSE_ramp = 1/Kv)\n\n', ...
        (1/(Kp_PI*K)) * 0.2 * 1000);

%% ====================== 3. BO PID VOI ANTI-WINDUP ======================
fprintf('--- 3. BO DIEU KHIEN PID (P + I + D) ---\n\n');

% PID controller: C(s) = Kp + Ki/s + Kd*s = (Kd*s^2 + Kp*s + Ki)/s
% Open-loop: L(s) = (Kd*s^2 + Kp*s + Ki) * K / [s^2*(tau*s + 1)]
% Closed-loop char.: tau*s^3 + (1 + K*Kd)*s^2 + K*Kp*s + K*Ki = 0
%
% Thiet ke bang pole placement voi dominant poles va α:
% (s^2 + 2ζω_n*s + ω_n^2)(s + α) = s^3 + (2ζω_n + α)s^2 + (ω_n^2 + 2ζω_n*α)s + ω_n^2*α
%
% So sanh voi he so closed-loop char.:
%   2ζω_n + α = (1 + K*Kd)/tau
%   ω_n^2 + 2ζω_n*α = K*Kp/tau
%   ω_n^2*α = K*Ki/tau

% Chon thong so
zeta_PID = 1.0;
omega_n_PID = 25;       % rad/s (thap hon de bo sung Kd co hieu qua)
alpha_PID = 1/tau - 2*zeta_PID*omega_n_PID;

if alpha_PID <= 0
    % Neu alpha am, giam omega_n
    omega_n_PID = (1/tau) / (4*zeta_PID);  % = 1/(4*zeta*tau) dam bao alpha > 0
    alpha_PID = 1/tau - 2*zeta_PID*omega_n_PID;
end

% Tinh Kp, Ki, Kd
A1 = 1/tau;          % He so s^2 cua closed-loop char (khi chia cho tau)
B1 = (1 + K*0)/tau;  % = 1/tau (khi Kd=0)
% Khi Kd > 0, he so s^2 tang len: (1 + K*Kd)/tau = 2ζω_n + α
% Neu Kd am, he so s^2 giam - co the gay instability
% Vi the Kd nen chon Kd >= 0 de dam bao (1 + K*Kd)/tau > 0

% Giai phuong trinh:
% 2ζω_n + α = (1 + K*Kd)/tau  =>  Kd = (tau*(2ζω_n + α) - 1)/K
% ω_n^2 + 2ζω_n*α = K*Kp/tau  =>  Kp = tau*(ω_n^2 + 2ζω_n*α)/K
% ω_n^2*α = K*Ki/tau  =>  Ki = tau*ω_n^2*α/K

Kd_PID = (tau*(2*zeta_PID*omega_n_PID + alpha_PID) - 1) / K;
Kp_PID = tau*(omega_n_PID^2 + 2*zeta_PID*omega_n_PID*alpha_PID) / K;
Ki_PID = tau*omega_n_PID^2*alpha_PID / K;

% Dam bao Kd >= 0 (neu am thi dat = 0 va tinh lai)
if Kd_PID < 0
    fprintf('  Canh bao: Kd < 0 voi ω_n = %.0f. Dat Kd = 0 va thu PI.\n', omega_n_PID);
    Kd_PID = 0;
    Kp_PID = tau*omega_n_PID^2/K;
    Ki_PID = tau*omega_n_PID*(1/tau - 2*zeta_PID*omega_n_PID)*omega_n_PID/K;
    % Recompute alpha for stability
    alpha_PID = 1/tau - 2*zeta_PID*omega_n_PID;
end

% Anti-windup: K_aw = 1/Ki (heuristic)
K_aw = 1/Ki_PID;

fprintf('  Chon ζ = %.2f, ω_n = %.0f rad/s\n', zeta_PID, omega_n_PID);
fprintf('  α (pole phu) = %.2f rad/s\n', alpha_PID);
fprintf('  Kp = %.2f V/m\n', Kp_PID);
fprintf('  Ki = %.2f V/(m·s)\n', Ki_PID);
fprintf('  Kd = %.4f V·s/m\n', Kd_PID);
fprintf('  K_aw (anti-windup gain) = 1/Ki = %.4f\n\n', K_aw);

%% ====================== 4. CHON BO PID DE THIET KE ====================
fprintf('--- 4. CHON PID DE THIET KE (KET QUA CUOI) ---\n\n');

% Chon PI (vi Kd rat nho, hieu qua khong dang ke; PI giup khang nhieu)
Kp_final = Kp_PI;
Ki_final = Ki_PI;
Kd_final = 0;
K_aw_final = 1/Ki_final;

fprintf('  CHON BO PI VOI:\n');
fprintf('    Kp = %.2f V/m\n', Kp_final);
fprintf('    Ki = %.2f V/(m·s)\n', Ki_final);
fprintf('    Kd = %.4f V·s/m\n', Kd_final);
fprintf('    K_aw = %.4f (anti-windup)\n\n', K_aw_final);

%% ====================== 5. PHAN TICH ON DINH & BIEN ====================
fprintf('--- 5. PHAN TICH ON DINH & BIEN ---\n\n');

% Tao bo PI controller (cho open-loop analysis)
C_PI = tf([Kp_final, Ki_final], [1, 0]);
L_PI = C_PI * P;       % Open-loop
T_PI = feedback(L_PI, 1);  % Closed-loop (unity feedback)

% Poles va zeros
fprintf('  Open-loop poles cua L(s) = C(s)*P(s):\n');
p_ol = pole(L_PI);
for k = 1:length(p_ol)
    fprintf('    p%d = %.2f %+.2fj\n', k, real(p_ol(k)), imag(p_ol(k)));
end

fprintf('  Closed-loop poles cua T(s):\n');
p_cl = pole(T_PI);
for k = 1:length(p_cl)
    fprintf('    p%d = %.2f %+.2fj\n', k, real(p_cl(k)), imag(p_cl(k)));
end

% Gain margin va phase margin
[Gm, Pm, Wcg, Wcp] = margin(L_PI);
fprintf('\n  Gain margin:   %.2f dB (tai %.2f rad/s)\n', 20*log10(Gm), Wcg);
fprintf('  Phase margin:  %.2f deg (tai %.2f rad/s)\n\n', Pm, Wcp);

% Step response characteristics
S = stepinfo(T_PI, 'SettlingTimeThreshold', 0.02);
fprintf('  Step response (closed-loop, 1m reference):\n');
fprintf('    Rise time (10%%-90%%):    %.0f ms\n', S.RiseTime*1000);
fprintf('    Settling time (2%%):     %.0f ms\n', S.SettlingTime*1000);
fprintf('    Overshoot:               %.2f%%\n', S.Overshoot);
fprintf('    Steady-state value:      %.4f m\n\n', S.SteadyState);

%% ====================== 6. BODE PLOT OPEN-LOOP =========================
fprintf('--- 6. BODE PLOT OPEN-LOOP ---\n\n');

figure('Name', 'Open-Loop Bode', 'Position', [100 100 900 600]);
margin(L_PI);
grid on;
title('Bode Plot cua L(s) = C(s) * P(s) voi PI controller');

%% ====================== 7. ROOT LOCUS ===================================
fprintf('--- 7. ROOT LOCUS ---\n\n');

figure('Name', 'Root Locus', 'Position', [100 750 700 500]);
rlocus(L_PI);
grid on;
title('Root Locus cua L(s) = C(s) * P(s)');
% Ve diem design
sgrid;

%% ====================== 8. CLOSED-LOOP STEP RESPONSE ===================
fprintf('--- 8. CLOSED-LOOP STEP RESPONSE ---\n\n');

figure('Name', 'Closed-Loop Step Response', 'Position', [850 100 900 600]);
step(T_PI, 1);
grid on;
title('Closed-loop Step Response (1 m reference)');

% So sanh voi P-only
C_P = tf(Kp_P, 1);
T_P = feedback(C_P * P, 1);
hold on;
step(T_P, 1);
legend('PI Controller', 'P-only Controller', 'Location', 'Best');

%% ====================== 9. KET QUA DIEU KHIEN ==========================
fprintf('--- 9. KET QUA DIEU KHIEN ---\n\n');

% Lap bang ket qua
fprintf('  Bang so sanh 3 bo dieu khien:\n');
fprintf('  %-20s %-15s %-15s %-15s\n', 'Thong so', 'P', 'PI', 'PID');
fprintf('  %s\n', repmat('-', 1, 65));

S_P = stepinfo(feedback(Kp_P*P, 1));
S_PID = stepinfo(feedback(Kp_PID + Ki_PID/tf([1 0]) + Kd_PID*tf([1 0]), 1) * P);

fprintf('  %-20s %-15.2f %-15.2f %-15.2f\n', 'Kp (V/m)', Kp_P, Kp_PI, Kp_PID);
fprintf('  %-20s %-15s %-15.2f %-15.2f\n', 'Ki (V/(m.s))', '-', Ki_PI, Ki_PID);
fprintf('  %-20s %-15s %-15s %-15.4f\n', 'Kd (V.s/m)', '-', '-', Kd_PID);
fprintf('  %-20s %-15.0f %-15.0f %-15.0f\n', 'Rise time (ms)', S_P.RiseTime*1000, S.RiseTime*1000, S_PID.RiseTime*1000);
fprintf('  %-20s %-15.0f %-15.0f %-15.0f\n', 'Settling (ms)', S_P.SettlingTime*1000, S.SettlingTime*1000, S_PID.SettlingTime*1000);
fprintf('  %-20s %-15.2f %-15.2f %-15.2f\n', 'Overshoot (%%)', S_P.Overshoot, S.Overshoot, S_PID.Overshoot);
fprintf('  %-20s %-15.0f %-15.0f %-15.0f\n', 'Phase Margin (°)', Pm_P, Pm, Pm_PID);
fprintf('  %-20s %-15.0f %-15.0f %-15.0f\n', 'Gain Margin (dB)', 20*log10(Gm_P), 20*log10(Gm), 20*log10(Gm_PID));

% Tinh phase margin cho P-only
[Gm_P, Pm_P, ~, ~] = margin(Kp_P * P);
[Gm_PID, Pm_PID, ~, ~] = margin((Kp_PID + Ki_PID/tf([1 0]) + Kd_PID*tf([1 0])) * P);

fprintf('\n  Ket luan: Su dung PI controller cho he thong\n\n');

%% ====================== 10. SAVE CONTROLLER ============================
save('controller.mat', ...
    'Kp_final', 'Ki_final', 'Kd_final', 'K_aw_final', ...
    'C_PI', 'T_PI', 'L_PI', 'Kp_P', 'Ki_PID', 'Kd_PID');

fprintf('  >> Da luu controller vao file: controller.mat\n');
fprintf('  >> Su dung file: simulation.m\n\n');
