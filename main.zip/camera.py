"""Basler camera wrapper sử dụng pypylon."""
from __future__ import annotations

import time
from typing import Any

import numpy as np
from pypylon import pylon


class BaslerCamera:
    """Wrapper mỏng cho pypylon.InstantCamera, hỗ trợ context manager.

    Mặc định cho camera MONO: output numpy array 1-channel (H, W) uint8.
    Nếu dùng camera color, bỏ comment 2 dòng OutputPixelFormat/OutputBitAlignment
    trong __init__ để convert sang BGR8 3-channel.

    Kết nối: connect() → apply(settings) → grab_one() → close().
    """

    def __init__(self, serial_number: str | None = None) -> None:
        self._tl_factory = pylon.TlFactory.GetInstance()
        self._camera: pylon.InstantCamera | None = None
        self._serial = serial_number
        self._converter = pylon.ImageFormatConverter()
        # --- MONO camera (mặc định): giữ nguyên Mono8, grab_one() trả về (H, W) ---
        # --- COLOR camera: bỏ comment 2 dòng dưới, grab_one() trả về (H, W, 3) BGR ---
        # self._converter.OutputPixelFormat = pylon.PixelType_BGR8packed
        # self._converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

    def __enter__(self) -> BaslerCamera:
        self.connect()
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def connect(self) -> None:
        devices = self._tl_factory.EnumerateDevices()
        if not devices:
            raise RuntimeError(
                "Không tìm thấy camera Basler nào trên hệ thống. Kiểm tra:\n"
                "  - Cáp USB/Ethernet đã cắm và camera đã bật nguồn\n"
                "  - Pylon Viewer mở được camera không? (nếu có → driver OK)\n"
                "  - Trên Linux: quyền USB (udev rule) hoặc biến GENICAM_GENTL64_PATH\n"
                "  - Đã cài pypylon tương thích với pylon SDK đang dùng"
            )
        available_serials = [dev.GetSerialNumber() for dev in devices]
        target: pylon.DeviceInfo | None = None
        if self._serial:
            for dev in devices:
                if dev.GetSerialNumber() == self._serial:
                    target = dev
                    break
            if target is None:
                raise RuntimeError(
                    f"Không tìm thấy camera serial '{self._serial}'.\n"
                    f"  Serials khả dụng pypylon thấy được: {available_serials}\n"
                    f"  → Sửa 'serial_number' trong config.json cho đúng, "
                    f"hoặc đặt null để tự lấy camera đầu tiên."
                )
        else:
            target = devices[0]
        self._camera = pylon.InstantCamera(self._tl_factory.CreateDevice(target))
        self._camera.Open()
        # GigE buffer tuning: mặc định pylon chỉ cấp ~3 buffer. Tăng lên 10 để có
        # đệm khi bandwidth mạng chậm → tránh "buffer was incompletely grabbed".
        self._safe_set("MaxNumBuffer", 10)
        info = self._camera.DeviceInfo
        print(f"Đã kết nối: {info.GetModelName()} (serial={info.GetSerialNumber()})")

    def apply(self, settings: dict[str, Any]) -> None:
        """Áp cấu hình từ dict. Bỏ qua key không tồn tại trên camera (vd: GainRaw).

        Mapping config_key → (tên node trong pylon, caster):
        """
        if self._camera is None:
            raise RuntimeError("Camera chưa kết nối. Gọi connect() trước.")
        applied: list[str] = []
        # Áp Width/Height theo cặp (một số camera yêu cầu set cả hai).
        if "width" in settings and "height" in settings:
            if self._safe_set("Width", int(settings["width"])):
                applied.append(f"Width={settings['width']}")
            if self._safe_set("Height", int(settings["height"])):
                applied.append(f"Height={settings['height']}")
        # Các node đơn lẻ.
        single_map: list[tuple[str, str, type]] = [
            ("offset_x", "OffsetX", int),
            ("offset_y", "OffsetY", int),
            ("exposure_time_us", "ExposureTimeAbs", float),
            ("gain_db", "Gain", float),
            ("gain_raw", "GainRaw", int),
            ("frame_rate", "AcquisitionFrameRateAbs", float),
        ]
        for cfg_key, node, caster in single_map:
            if cfg_key in settings and self._safe_set(node, caster(settings[cfg_key])):
                applied.append(f"{node}={settings[cfg_key]}")
        if settings.get("reverse_x") and self._safe_set("ReverseX", True):
            applied.append("ReverseX=True")
        if settings.get("reverse_y") and self._safe_set("ReverseY", True):
            applied.append("ReverseY=True")
        print(f"Đã áp cấu hình: {', '.join(applied) or '(không có node nào khả dụng)'}")

    def _safe_set(self, attr: str, value: Any) -> bool:
        """Set node pylon nếu tồn tại trên camera. Trả True nếu set được.

        Khác biệt giữa các model Basler: camera acA thường có Gain (dB),
        một số model rẻ hơn chỉ có GainRaw. Hàm này tránh crash khi thiếu node.
        """
        cam = self._camera
        if cam is None:
            return False
        try:
            getattr(cam, attr).SetValue(value)
            return True
        except AttributeError:
            return False  # camera không có node này
        except Exception as e:
            print(f"[warn] {attr}={value} thất bại: {e}")
            return False

    def grab_one(self, timeout_ms: int = 5000) -> np.ndarray:
        """Chụp đúng 1 frame. Trả về (H, W) uint8 nếu mono, (H, W, 3) BGR nếu color.

        Retry 1 lần nếu grab gặp buffer underrun trên GigE (frame truyền thiếu gói
        do bandwidth mạng không đủ kịp). Nếu vẫn fail ở lần 2 → raise.
        """
        if self._camera is None:
            raise RuntimeError("Camera chưa kết nối. Gọi connect() trước.")
        cam = self._camera
        for attempt in range(2):
            cam.StartGrabbingMax(1)
            grab = cam.RetrieveResult(timeout_ms, pylon.TimeoutHandling_ThrowException)
            try:
                if grab.GrabSucceeded():
                    return self._converter.Convert(grab).GetArray()
                err = grab.ErrorDescription or ""
                if attempt == 0 and "incompletely" in err.lower():
                    print(f"[warn] Buffer underrun, retry sau 100ms ({err[:60]})")
                    time.sleep(0.1)
                    continue
                raise RuntimeError(f"Grab thất bại: {err}")
            finally:
                grab.Release()
        # Vòng lặp chỉ thoát qua `continue` (attempt=0) hoặc `raise` (raise
        # đã return). Đoạn này chỉ chạy nếu attempt=1 mà grab fail mà không
        # có raise nào trong nhánh (không thể xảy ra), nhưng giữ để mypy hài lòng.
        raise RuntimeError("Grab thất bại sau retry.")

    def close(self) -> None:
        if self._camera is not None and self._camera.IsOpen():
            self._camera.Close()
        self._camera = None
