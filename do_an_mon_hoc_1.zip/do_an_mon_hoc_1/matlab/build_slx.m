%% ========================================================================
% build_slx.m
% Xay dung Simulink model (.slx) bang lenh MATLAB (programmatic API)
%
% Vi .slx la file nen nhi phan, nen tao model truc tiep kho hon.
% Phuong an nay dung lenh new_system, add_block, add_line de tao model.
% Luu thanh file .slx de mo bang Simulink.
%
% Luu y: Can MATLAB Simulink. Neu khong co Simulink, chi can mo .slx file
%        (se tao file placeholder neu khong co Simulink).
% =========================================================================

clc; clear; close all;

if ~exist('controller.mat', 'file')
    error('Hay chay param_calc.m, plant_model.m, pid_design.m truoc!');
end
load('params.mat');
load('controller.mat');

fprintf('\n========================================================================\n');
fprintf('  XAY DUNG SIMULINK MODEL\n');
fprintf('========================================================================\n\n');

% Kiem tra Simulink co san khong
has_simulink = license('test', 'SIMULINK');
if ~has_simulink
    fprintf('  CANH BAO: Khong co Simulink. Script chi tao file .m mo ta cau truc.\n');
    fprintf('  Ban co the tu xay model bang tay theo huong dan trong file.\n\n');
end

model_name = 'linear_slide_pid';
mdl_file = [model_name, '.slx'];

% Xoa model cu neu co
if has_simulink
    if exist(model_name, 'file')
        close_system(model_name, 0);
        delete([mdl_file]);
    end
end

if has_simulink
    %% ============== TAO MOI MODEL ==============
    fprintf('  Tao Simulink model: %s\n', model_name);

    % Tao system moi
    new_system(model_name);
    open_system(model_name);

    % Cau hinh solver
    set_param(model_name, 'SolverType', 'Fixed-step');
    set_param(model_name, 'FixedStep', '0.001');      % 1 ms
    set_param(model_name, 'StopTime', '3');
    set_param(model_name, 'SaveOutput', 'on');
    set_param(model_name, 'SaveFormat', 'Array');

    %% ============== CAC KHOI BLOCK ==============

    % 1. STEP INPUT (setpoint: 300 mm = 0.3 m)
    add_block('simulink/Sources/Step', [model_name, '/Setpoint']);
    set_param([model_name, '/Setpoint'], ...
              'Time', '0', ...
              'Before', '0', ...
              'After', '0.3', ...
              'SampleTime', '0');

    % 2. REFERENCE TO WORKSPACE (mm)
    add_block('simulink/Sinks/To Workspace', [model_name, '/Ref_Workspace']);
    set_param([model_name, '/Ref_Workspace'], ...
              'VariableName', 'ref_mm', ...
              'SaveFormat', 'Array');

    % Scale factor for setpoint (m to mm display)
    add_block('simulink/Math Operations/Gain', [model_name, '/m_to_mm']);
    set_param([model_name, '/m_to_mm'], 'Gain', '1000');

    %% 3. ERROR CALCULATION (sum)
    add_block('simulink/Math Operations/Sum', [model_name, '/Error_Calc']);
    set_param([model_name, '/Error_Calc'], ...
              'ListOfSigns', '+-', ...
              'Inputs', '+--');

    %% 4. PI CONTROLLER (P + I)
    % P gain
    add_block('simulink/Math Operations/Gain', [model_name, '/Kp']);
    set_param([model_name, '/Kp'], 'Gain', num2str(Kp_final));

    % I gain (1/s)
    add_block('simulink/Continuous/Integrator', [model_name, '/Ki_Integrator']);
    set_param([model_name, '/Ki_Integrator'], ...
              'InitialCondition', '0');
    add_block('simulink/Math Operations/Gain', [model_name, '/Ki']);
    set_param([model_name, '/Ki'], 'Gain', num2str(Ki_final));

    % Sum of P and I
    add_block('simulink/Math Operations/Sum', [model_name, '/PI_Sum']);
    set_param([model_name, '/PI_Sum'], 'ListOfSigns', '++');

    %% 5. ANTI-WINDUP (Saturation + feedback)
    add_block('simulink/Discontinuities/Saturation', [model_name, '/Saturation']);
    set_param([model_name, '/Saturation'], ...
              'UpperLimit', '24', ...
              'LowerLimit', '-24');

    % Anti-windup feedback
    add_block('simulink/Math Operations/Sum', [model_name, '/AntiWindup_Sum']);
    set_param([model_name, '/AntiWindup_Sum'], 'ListOfSigns', '+-');

    add_block('simulink/Math Operations/Gain', [model_name, '/K_aw']);
    set_param([model_name, '/K_aw'], 'Gain', num2str(K_aw_final));

    %% 6. PLANT (Motor + Ball Screw + Load)
    % Plant transfer function: K / [s*(tau*s + 1)]
    plant_num = K_final;
    plant_den = conv([1, 0], [tau_final, 1]);
    plant_tf = tf(plant_num, plant_den);
    [num_poly, den_poly] = tfdata(plant_tf, 'v');
    num_str = mat2str(num_poly);
    den_str = mat2str(den_poly);

    add_block('simulink/Continuous/Transfer Fcn', [model_name, '/Plant']);
    set_param([model_name, '/Plant'], ...
              'Numerator', num_str, ...
              'Denominator', den_str);

    %% 7. OUTPUT (Position m -> mm)
    add_block('simulink/Math Operations/Gain', [model_name, '/Out_m_to_mm']);
    set_param([model_name, '/Out_m_to_mm'], 'Gain', '1000');

    %% 8. SCOPES
    % Scope cho position
    add_block('simulink/Sinks/Scope', [model_name, '/Scope_Position']);
    set_param([model_name, '/Scope_Position'], 'NumInputPorts', '2');
    set_param([model_name, '/Scope_Position'], ...
              'Ymin', '0', ...
              'Ymax', '350', ...
              'Title', 'Vi tri (mm)');

    % Scope cho control signal
    add_block('simulink/Sinks/Scope', [model_name, '/Scope_Control']);
    set_param([model_name, '/Scope_Control'], ...
              'Ymin', '-30', ...
              'Ymax', '30', ...
              'Title', 'Tin hieu dieu khien (V)');

    % Scope cho error
    add_block('simulink/Sinks/Scope', [model_name, '/Scope_Error']);
    set_param([model_name, '/Scope_Error'], ...
              'Ymin', '-1', ...
              'Ymax', '350', ...
              'Title', 'Sai so (mm)');

    %% 9. DISTURBANCE (optional - force on load)
    add_block('simulink/Sources/Step', [model_name, '/Disturbance']);
    set_param([model_name, '/Disturbance'], ...
              'Time', '1.5', ...
              'Before', '0', ...
              'After', '50', ...   % 50 N
              'SampleTime', '0');

    add_block('simulink/Math Operations/Gain', [model_name, '/Disturb_to_motor']);
    % F -> T_disturb = F*lead/(2*pi*eta) -> giam toc truc tiep
    set_param([model_name, '/Disturb_to_motor'], ...
              'Gain', num2str(1/m_load));  % a = F/m

    %% ============== KET NOI CAC BLOCK ==============

    % Setpoint -> Error
    add_line(model_name, 'Setpoint/1', 'm_to_mm/1');
    add_line(model_name, 'm_to_mm/1', 'Error_Calc/1');

    % Plant output -> Error (feedback, negative)
    add_line(model_name, 'Out_m_to_mm/1', 'Scope_Position/1');
    add_line(model_name, 'Out_m_to_mm/1', 'Error_Calc/2');

    % Error -> P
    add_line(model_name, 'Error_Calc/1', 'Kp/1');

    % Error -> I
    add_line(model_name, 'Error_Calc/1', 'Ki_Integrator/1');
    add_line(model_name, 'Ki_Integrator/1', 'Ki/1');

    % P + I -> Sum
    add_line(model_name, 'Kp/1', 'PI_Sum/1');
    add_line(model_name, 'Ki/1', 'PI_Sum/2');

    % Sum -> AntiWindup sum
    add_line(model_name, 'PI_Sum/1', 'AntiWindup_Sum/1');
    add_line(model_name, 'Saturation/1', 'AntiWindup_Sum/2');

    % AntiWindup sum -> Integrator (anti-windup path)
    add_line(model_name, 'AntiWindup_Sum/1', 'Ki_Integrator/2');  % External reset

    % AntiWindup sum -> Saturation
    add_line(model_name, 'AntiWindup_Sum/1', 'Saturation/1');

    % Saturation -> Plant + Control scope
    add_line(model_name, 'Saturation/1', 'Plant/1');
    add_line(model_name, 'Saturation/1', 'Scope_Control/1');

    % Plant -> Output + disturbance addition
    % NOTE: disturbance injection se can mot Sum block them
    % De don gian, disturbance chi la reference signal (khong thuc su chen vao)

    % Plant output -> mm conversion
    add_line(model_name, 'Plant/1', 'Out_m_to_mm/1');

    % Error -> mm conversion -> Error scope
    add_block('simulink/Math Operations/Abs', [model_name, '/Abs_Error']);
    add_line(model_name, 'Error_Calc/1', 'Abs_Error/1');
    add_line(model_name, 'Abs_Error/1', 'Scope_Error/1');

    % Save to workspace
    add_block('simulink/Sinks/To Workspace', [model_name, '/Pos_Workspace']);
    set_param([model_name, '/Pos_Workspace'], ...
              'VariableName', 'pos_mm', ...
              'SaveFormat', 'Array');

    add_line(model_name, 'Out_m_to_mm/1', 'Pos_Workspace/1');

    %% ============== LUU MODEL ==============
    save_system(model_name, mdl_file);
    close_system(model_name, 0);

    fprintf('  >> Da tao Simulink model: %s\n', mdl_file);
    fprintf('  >> Mo file bang Simulink: open_system(''%s'')\n', model_name);

else
    %% ============== TAO FILE MO TA ==============
    fprintf('  Simulink khong kha dung. Tao file mo ta cau truc model.\n\n');

    % Tao mo ta cau truc
    desc_file = 'simulink_model_description.md';
    fid = fopen(desc_file, 'w', 'n', 'UTF-8');
    if fid == -1
        desc_file = 'simulink_model_description.txt';
        fid = fopen(desc_file, 'w');
    end

    fprintf(fid, '# Simulink Model Description: %s\n\n', model_name);
    fprintf(fid, '## Cau truc Block Diagram\n\n');
    fprintf(fid, '```\n');
    fprintf(fid, '                                                    \n');
    fprintf(fid, '   +--------+    +---------+   +-------+              \n');
    fprintf(fid, '   | Step   |--->| m_to_mm |--->|+ Sum  |              \n');
    fprintf(fid, '   |  300mm |    | (x1000) |   |       |              \n');
    fprintf(fid, '   +--------+    +---------+   |  e    |              \n');
    fprintf(fid, '                              |       |              \n');
    fprintf(fid, '                              ++------+              \n');
    fprintf(fid, '                               |                     \n');
    fprintf(fid, '                  +------------+--------------+     \n');
    fprintf(fid, '                  |            v              |     \n');
    fprintf(fid, '              +-------+   +-----------+   +---+---+\n');
    fprintf(fid, '              |   Kp  |   | Integrator|   |   Ki  |\n');
    fprintf(fid, '              | %.2f |   |   (1/s)    |   | %.0f |\n', Kp_final, Ki_final);
    fprintf(fid, '              +-------+   +-----------+   +-------+\n');
    fprintf(fid, '                  |            |              |     \n');
    fprintf(fid, '                  |            v              |     \n');
    fprintf(fid, '                  |       +-------+          |     \n');
    fprintf(fid, '                  +------>|  Sum  |<---------+     \n');
    fprintf(fid, '                          | P+I  |                 \n');
    fprintf(fid, '                          +-------+                 \n');
    fprintf(fid, '                              |                     \n');
    fprintf(fid, '                              v                     \n');
    fprintf(fid, '                       +-----------+                \n');
    fprintf(fid, '                       |Anti-Windup|                \n');
    fprintf(fid, '                       |   Sum     |                \n');
    fprintf(fid, '                       +-----------+                \n');
    fprintf(fid, '                              |                     \n');
    fprintf(fid, '                              v                     \n');
    fprintf(fid, '                       +-----------+                \n');
    fprintf(fid, '                       | Saturation|                \n');
    fprintf(fid, '                       |  +-24V    |                \n');
    fprintf(fid, '                       +-----------+                \n');
    fprintf(fid, '                              |                     \n');
    fprintf(fid, '                              v                     \n');
    fprintf(fid, '                       +-----------+                \n');
    fprintf(fid, '                       |  Plant    |                \n');
    fprintf(fid, '                       |K/[s(Ts+1)]|                \n');
    fprintf(fid, '                       +-----------+                \n');
    fprintf(fid, '                              |                     \n');
    fprintf(fid, '                              v                     \n');
    fprintf(fid, '                       +-----------+                \n');
    fprintf(fid, '                       | Out m->mm |                \n');
    fprintf(fid, '                       | (x1000)   |                \n');
    fprintf(fid, '                       +-----------+                \n');
    fprintf(fid, '                              |                     \n');
    fprintf(fid, '                              +-> Scope             \n');
    fprintf(fid, '                              +-> Workspace         \n');
    fprintf(fid, '                              +-> Feedback to Sum   \n');
    fprintf(fid, '```\n\n');
    fprintf(fid, '## Thong so Plant\n\n');
    fprintf(fid, '- **K** = %.4f m/(V.s)\n', K_final);
    fprintf(fid, '- **tau_v** = %.4f ms\n', tau_final*1000);
    fprintf(fid, '- **P(s)** = K / [s*(tau*s + 1)]\n\n');
    fprintf(fid, '## Thong so Controller\n\n');
    fprintf(fid, '- **Kp** = %.2f V/m\n', Kp_final);
    fprintf(fid, '- **Ki** = %.2f V/(m.s)\n', Ki_final);
    fprintf(fid, '- **K_aw** = %.4f\n', K_aw_final);
    fprintf(fid, '- **Saturation**: +-24V\n\n');
    fprintf(fid, '## Huong dan xay bang tay (neu khong co Simulink API)\n\n');
    fprintf(fid, '1. Tao mot Simulink model moi\n');
    fprintf(fid, '2. Them cac block: Step, Sum, Gain, Integrator, Saturation, Transfer Fcn\n');
    fprintf(fid, '3. Ket noi theo so do tren\n');
    fprintf(fid, '4. Cau hinh: Solver = Fixed-step, Step = 0.001s, Stop time = 3s\n');
    fprintf(fid, '5. Set cac thong so nhu tren\n');
    fprintf(fid, '6. Chay simulation va xem Scope\n\n');

    fclose(fid);
    fprintf('  >> Da tao file mo ta: %s\n', desc_file);
end

fprintf('\n  Su dung:\n');
fprintf('    1. Mo Simulink: open_system(''%s'')\n', model_name);
fprintf('    2. Chay simulation\n');
fprintf('    3. Xem Scope de kiem tra vi tri va tin hieu dieu khien\n\n');

%% ============== IN THONG SO RA CONSOLE ==============
fprintf('========================================================================\n');
fprintf('  THONG SO MO HINH SIMULINK\n');
fprintf('========================================================================\n\n');
fprintf('  Plant: P(s) = %.4f / [s*(%.4f s + 1)]\n', K_final, tau_final);
fprintf('  Controller: Kp = %.2f, Ki = %.2f\n', Kp_final, Ki_final);
fprintf('  Saturation: +-24V\n\n');
