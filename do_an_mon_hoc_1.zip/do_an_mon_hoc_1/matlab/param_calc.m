%% ========================================================================
% param_calc.m
% Tinh toan thong so he truyen dong dien dieu khien vi tri ban truot tuyen tinh
%
% Muc tieu: Xay dung bang thong so ky thuat cho he thong
% - Dong co Servo DC 24V
% - Vit me - dai oc (ball screw), lead 5 mm/rev
% - Encoder phan hoi vi tri 2500 ppr (quadrature: 10000 counts/rev)
%
% Yeu cau thiet ke:
%   - Hanh trinh:      300 mm
%   - Sai so vi tri:   <= 0.5 mm
%   - Khoi luong tai:  10 kg
%   - Toc do toi da:   0.2 m/s
%
% Tac gia: Do an mon hoc - He truyen dong dien
% Ngay:    2026
% =========================================================================

clc; clear; close all;
format shortEng; format compact;

fprintf('========================================================================\n');
fprintf('  TINH TOAN THONG SO HE TRUYEN DONG DIEN - BAN TRUOT TUYEN TINH\n');
fprintf('========================================================================\n\n');

%% ====================== 1. THONG SO YEU CAU =============================
fprintf('--- 1. THONG SO YEU CAU THIET KE ---\n\n');

L_travel    = 300e-3;          % Hanh trinh (m)
e_max       = 0.5e-3;          % Sai so vi tri cho phep (m)
m_load      = 10;              % Khoi luong tai (kg)
v_max       = 0.2;             % Toc do tuyen tinh toi da (m/s)
g_accel     = 9.81;            % Gia toc trong truong (m/s^2)

% Thoi gian tang toc mong muon (de uoc luoc luc qua trinh)
t_accel     = 0.1;             % Thoi gian tang toc (s) - chon 0.1s de dat v_max

fprintf('  Hanh trinh:           %.0f mm\n', L_travel*1000);
fprintf('  Sai so vi tri:        <= %.1f mm\n', e_max*1000);
fprintf('  Khoi luong tai:       %.0f kg\n', m_load);
fprintf('  Toc do toi da:        %.2f m/s\n', v_max);
fprintf('  Thoi gian tang toc:   %.2f s\n\n', t_accel);

%% ====================== 2. LUA CHON LINH KIEN ===========================
fprintf('--- 2. LUA CHON LINH KIEN ---\n\n');

% === 2.1. Dong co Servo DC 24V ===
% Chon dong co DC servo 24V, cong suat vua phai (Maxon RE25 hoac tuong duong)
motor.V_rated   = 24;           % Dien ap dinh muc (V)
motor.I_rated   = 4.0;          % Dong dinh muc (A)
motor.T_rated   = 0.15;         % Mo men dinh muc (Nm)
motor.n_rated   = 6000;         % Toc do dinh muc (RPM)
motor.Ra        = 1.0;          % Dien tro phan ung (Ohm)
motor.La        = 0.5e-3;       % Dien cam phan ung (H)
motor.Kt        = 0.05;         % Hang so mo men (Nm/A)
motor.Ke        = 0.05;         % Hang so suc dien dong nguoc (V.s/rad)
motor.Jm        = 50e-7;        % Mo men quan tinh roto (kg.m^2)
motor.Bm        = 1e-6;         % He so ma sat nhot cua dong co (Nm.s/rad)

% Luu y: Trong he SI, Kt = Ke (vi nhien don vi quoc te)

% === 2.2. Vit me (Ball Screw) ===
% Lead = khoang cach truot moi vong quay
screw.lead      = 5e-3;         % Buoc vit (m/rev) = 5 mm/rev
screw.diameter  = 16e-3;        % Duong kinh danh nghia (m)
screw.eta       = 0.90;         % Hieu suat (90%)
screw.Jscrew    = 5e-7;         % Mo men quan tinh vit me quy doi ve truc (kg.m^2)

% === 2.3. Encoder ===
encoder.ppr      = 2500;        % Xung moi vong (pulses per revolution)
encoder.quad     = 4;           % He so quadrature (x4)
encoder.counts_rev = encoder.ppr * encoder.quad;  % Counts moi vong

% === 2.4. Ray dan huong tuyen tinh (Linear Guide) ===
guide.mu        = 0.02;         % He so ma sat
guide.Bv        = 5;            % He so can nhot tuyen tinh (N.s/m)

fprintf('  2.1. Dong co Servo DC:\n');
fprintf('       V_rated=%.0fV, T_rated=%.2fNm, n_rated=%.0f RPM\n', ...
        motor.V_rated, motor.T_rated, motor.n_rated);
fprintf('       Ra=%.2f Ohm, La=%.1f mH, Kt=%.3f Nm/A, Ke=%.3f V.s/rad\n', ...
        motor.Ra, motor.La*1000, motor.Kt, motor.Ke);
fprintf('       Jm=%.1e kg.m^2, Bm=%.1e Nm.s/rad\n\n', motor.Jm, motor.Bm);

fprintf('  2.2. Vit me (Ball Screw):\n');
fprintf('       Lead=%.1f mm/rev, duong kinh=%.0f mm, hieu suat=%.0f%%\n\n', ...
        screw.lead*1000, screw.diameter*1000, screw.eta*100);

fprintf('  2.3. Encoder:\n');
fprintf('       %d ppr, quadrature x%d = %d counts/rev\n', ...
        encoder.ppr, encoder.quad, encoder.counts_rev);
fprintf('       Phan giai vi tri: %.4f mm/count\n\n', ...
        screw.lead*1000/encoder.counts_rev);

fprintf('  2.4. Ray dan huong: mu=%.2f, Bv=%.1f N.s/m\n\n', guide.mu, guide.Bv);

%% ====================== 3. TINH TOAN LUC VA MO MEN =====================
fprintf('--- 3. TINH TOAN LUC VA MO MEN ---\n\n');

% Gia toc can thiet de dat van toc toi da trong thoi gian t_accel
a_accel = v_max / t_accel;     % Gia toc (m/s^2)

% Luc can thiet:
F_weight = m_load * g_accel;                       % Luc trong luc (N)
F_friction = guide.mu * F_weight;                  % Luc ma sat Coulomb (N)
F_viscous = guide.Bv * v_max;                      % Luc can nhot (N)
F_accel = m_load * a_accel;                        % Luc qua trinh (N)
F_total = F_weight + F_friction + F_viscous + F_accel;  % Tong luc (N)

fprintf('  Gia toc yeu cau:     %.2f m/s^2\n', a_accel);
fprintf('  Luc trong luc:       %.2f N\n', F_weight);
fprintf('  Luc ma sat Coulomb:  %.2f N\n', F_friction);
fprintf('  Luc can nhot:        %.2f N (tai v_max)\n', F_viscous);
fprintf('  Luc qua trinh:       %.2f N (tai a_accel)\n', F_accel);
fprintf('  --> Tong luc can:    %.2f N\n\n', F_total);

% Mo men can thiet tren truc dong co (quy doi qua vit me):
% F * lead = T * 2*pi * eta  =>  T = F * lead / (2*pi * eta)
T_required = F_total * screw.lead / (2 * pi * screw.eta);

% Toc do dong co can thiet de dat v_max:
n_required = v_max / screw.lead;                    % (rev/s)
n_required_rpm = n_required * 60;                   % (RPM)

fprintf('  Mo men can thiet (truc vit me): T_required = %.4f Nm\n', T_required);
fprintf('  Toc do can thiet:                n_required = %.0f RPM\n', n_required_rpm);

% Kiem tra lua chon dong co:
margin_torque = motor.T_rated / T_required;
margin_speed = motor.n_rated / n_required_rpm;

fprintf('  --> Du dinh mo men:  %.1f%% (yeu cau: 30-50%%)\n', margin_torque*100);
fprintf('  --> Du dinh toc do:  %.1f%% (yeu cau: 30-50%%)\n\n', margin_speed*100);

%% ====================== 4. QUY DOI THONG SO VE TRUC DONG CO ============
fprintf('--- 4. QUY DOI THONG SO VE TRUC DONG CO ---\n\n');

% Ti so quy doi: tu truc dong co sang truc tuyen tinh
% He so quy doi vi: lead/(2*pi)  [m/rad]
K_conv = screw.lead / (2*pi);    % m/rad

% Mo men quan tinh tai quy doi ve truc dong co
% J_load_reflected = m * (lead/(2*pi))^2 / eta
J_load_ref = m_load * K_conv^2 / screw.eta;

% He so can nhot quy doi
B_load_ref = guide.Bv * K_conv^2 / screw.eta;

% Mo men quan tinh tong (dong co + vit me + tai quy doi)
J_total = motor.Jm + screw.Jscrew + J_load_ref;

% He so can tong
B_total = motor.Bm + B_load_ref;

fprintf('  He so quy doi (K_conv = lead/2*pi): %.3e m/rad\n', K_conv);
fprintf('  Mo men quan tinh tai quy doi:        %.3e kg.m^2\n', J_load_ref);
fprintf('  Mo men quan tinh tong:               %.3e kg.m^2\n', J_total);
fprintf('  He so can tong:                     %.3e Nm.s/rad\n\n', B_total);

%% ====================== 5. HAM TRUYEN TU VOLTAGE SANG POSITION =========
fprintf('--- 5. HAM TRUYEN TU VOLTAGE SANG VI TRI ---\n\n');

% Tu phuong trinh dien - co:
% V_a(s) = (Ra*La)*s*i(s) + (Ra + Ke*Kt/Ra * ... )*i(s) (rut gon)
% Phuong trinh ro dien: V_a = Ra*i + La*di/dt + Ke*omega
% Phuong trinh co:    J_total * d(omega)/dt + B_total*omega = Kt*i
%
% Ham truyen tu voltage -> angular velocity:
% omega(s)/V_a(s) = Kt / [La*J_total*s^2 + (Ra*J_total + La*B_total)*s + (Ra*B_total + Ke*Kt)]
% Vi La rat nho (0.5 mH) so voi hang so khac, co the bo qua:
% omega(s)/V_a(s) = Kt / [Ra*J_total*s + (Ra*B_total + Ke*Kt)]
% = K_v / (tau_v*s + 1)
%
% Vi tri: x(s) = K_conv * omega(s) / s
%
% => P(s) = x(s)/V_a(s) = K_conv * Kt / [s*(Ra*J_total*s + (Ra*B_total + Ke*Kt))]

% He so cua ham truyen (mo hinh don gian hoa, bo qua La)
K_omega = motor.Kt / (motor.Ra * B_total + motor.Ke * motor.Kt);  % rad/s/V
tau_v = (motor.Ra * J_total) / (motor.Ra * B_total + motor.Ke * motor.Kt);  % s

% Ham truyen tu voltage -> angular velocity
num_omega = motor.Kt;
den_omega = [motor.Ra * J_total, (motor.Ra * B_total + motor.Ke * motor.Kt)];
G_omega = tf(num_omega, den_omega);

% Ham truyen tu voltage -> position (them integrator 1/s va he so quy doi)
K_position = K_conv * K_omega;   % m/(V.s) = velocity gain (m/s per V)
num_pos = K_position;
den_pos = conv([1, 0], [tau_v, 1]);  % s*(tau_v*s + 1)
G_position = tf(num_pos, den_pos);

fprintf('  omega(s)/V_a(s) = Kt / [Ra*J_total*s + (Ra*B_total + Ke*Kt)]\n');
fprintf('  K_v = %.3f rad/s/V (he so van toc dong co)\n', K_omega);
fprintf('  tau_v = %.3f ms (hang so thoi gian van toc)\n', tau_v*1000);
fprintf('  K_position = %.4f m/(V.s) = van toc (m/s) tren 1V\n', K_position);
fprintf('  --> P(s) = x(s)/V_a(s) = K_position / [s*(tau_v*s + 1)]\n');
fprintf('  --> P(s) = %.4f / [s*(%.4f s + 1)]\n\n', K_position, tau_v);

%% ====================== 6. PHAN GIAI HE THONG ===========================
fprintf('--- 6. PHAN GIAI HE THONG ---\n\n');

% Phan giai vi tri (mm/count)
pos_resolution = screw.lead / encoder.counts_rev;   % m/count
pos_resolution_mm = pos_resolution * 1000;          % mm/count

% Sai so do luong (1 count)
meas_error = pos_resolution_mm;

% So count can thiet de dat sai so 0.5mm
counts_for_05mm = e_max / pos_resolution;

fprintf('  Phan giai encoder:    %.4f mm/count\n', pos_resolution_mm);
fprintf('  Sai so do luong:      %.4f mm (1 count)\n', meas_error);
fprintf('  So count cho 0.5mm:   %.1f counts\n', counts_for_05mm);
fprintf('  --> Phan giai THOA MAN yeu cau <= 0.5 mm\n\n');

%% ====================== 7. GIOI HAN DIEU KHIEN ==========================
fprintf('--- 7. GIOI HAN DIEU KHIEN ---\n\n');

% Dien ap toi da dat tren dong co
V_max = motor.V_rated;

% Van toc toi da cua dong co khi khong tai (no-load speed)
omega_nl = V_max / motor.Ke;       % rad/s
n_nl_rpm = omega_nl * 60 / (2*pi); % RPM

% Van toc tuyen tinh toi da (khi khong tai)
v_max_no_load = K_conv * omega_nl;  % m/s

fprintf('  Dien ap dieu khien toi da: %.1f V\n', V_max);
fprintf('  Toc do khong tai:          %.0f RPM (%.2f m/s tuyen tinh)\n', ...
        n_nl_rpm, v_max_no_load);
fprintf('  --> Vuot qua yeu cau %.2f m/s cua he thong\n\n', v_max);

%% ====================== 8. KET QUA TONG HOP =============================
fprintf('========================================================================\n');
fprintf('  TOM TAT THONG SO THIET KE\n');
fprintf('========================================================================\n\n');

summary = {
    'Dong co Servo DC 24V', motor.V_rated, 'V';
    'Mo men dinh muc', motor.T_rated, 'Nm';
    'Hang so Kt', motor.Kt, 'Nm/A';
    'Hang so Ke', motor.Ke, 'V.s/rad';
    'Dien tro phan ung Ra', motor.Ra, 'Ohm';
    'Dien cam phan ung La', motor.La*1000, 'mH';
    'Mo men quan tinh Jm', motor.Jm, 'kg.m^2';
    'Buoc vit me (lead)', screw.lead*1000, 'mm/rev';
    'Hieu suat vit me', screw.eta*100, '%';
    'Encoder ppr', encoder.ppr, 'pulse/rev';
    'Encoder counts/rev (quad)', encoder.counts_rev, 'counts/rev';
    'Phan giai vi tri', pos_resolution_mm, 'mm/count';
    'He so quy doi K_conv', K_conv, 'm/rad';
    'He so van toc K_v', K_omega, 'rad/s/V';
    'Hang so thoi gian tau_v', tau_v*1000, 'ms';
    'He so vi tri K_position', K_position, 'm/(V.s)';
};

fprintf('  %-30s %15s %s\n', 'Thong so', 'Gia tri', 'Don vi');
fprintf('  %s\n', repmat('-', 1, 60));
for i = 1:size(summary, 1)
    name = summary{i, 1};
    value = summary{i, 2};
    unit = summary{i, 3};
    if value < 0.01 || value > 1000
        fprintf('  %-30s %15.3e %s\n', name, value, unit);
    else
        fprintf('  %-30s %15.3f %s\n', name, value, unit);
    end
end

fprintf('\n========================================================================\n');
fprintf('  Kiem tra yeu cau:\n');
fprintf('    - Hanh trinh:   %.0f mm (thiet ke: %.0f mm) -- OK\n', ...
        L_travel*1000, L_travel*1000);
fprintf('    - Sai so:       Phan giai %.4f mm < 0.5 mm -- OK\n', pos_resolution_mm);
fprintf('    - Tai:          Mo men du %.1f%%, toc do du %.1f%% -- OK\n', ...
        (margin_torque-1)*100, (margin_speed-1)*100);
fprintf('    - Toc do:       %.2f m/s <= %.2f m/s -- OK\n', v_max, v_max);
fprintf('========================================================================\n\n');

% Luu bien vao file .mat de cac script khac su dung
save('params.mat', ...
    'motor', 'screw', 'encoder', 'guide', ...
    'L_travel', 'e_max', 'm_load', 'v_max', 'g_accel', ...
    'a_accel', 'F_total', 'T_required', 'n_required_rpm', ...
    'K_conv', 'J_total', 'B_total', ...
    'K_omega', 'tau_v', 'K_position', ...
    'pos_resolution_mm', 'meas_error', ...
    'G_omega', 'G_position');

fprintf('  >> Da luu thong so vao file: params.mat\n');
fprintf('  >> Su dung cac file: plant_model.m, pid_design.m, simulation.m\n\n');
