"""Object-specific detection bằng template matching + Non-Max Suppression.

MultiTemplateInspector — 1 inspector xử lý được 3 bài toán:
  - ĐẾM      : ≥ min_count match (vd: ≥ 5 đai ốc).
  - PHÂN LOẠI : best match thuộc expected_template (vd: tem đúng).
  - VỊ TRÍ   : best match gần expected_position ± tolerance (vd: con rùa đúng chỗ).

Có thể bật nhiều tiêu chí cùng lúc (AND). Tách file để giữ inspector.py < 250 LOC.
"""
from __future__ import annotations

import cv2
import numpy as np

from inspector import BaseInspector, InspectionReport, InspectionResult, _to_gray


class MultiTemplateInspector(BaseInspector):
    """Tìm vật thể cụ thể bằng template matching. Một inspector xử lý 3 bài toán:

    - ĐẾM      : PASS nếu số match (sau NMS) ≥ min_count  (vd: ≥ 5 đai ốc).
    - PHÂN LOẠI : PASS nếu best match thuộc expected_template
                   (vd: best là "good_sticker" chứ không phải "bad").
    - VỊ TRÍ   : PASS nếu best match gần expected_position ± tolerance
                   (vd: con rùa ở đúng chỗ so với ảnh mẫu).

    Có thể bật nhiều tiêu chí cùng lúc (AND). Templates là dict {tên: đường dẫn}.
    """

    name = "MultiTemplate"

    def __init__(
        self,
        templates: dict[str, str],
        threshold: float = 0.85,
        nms_radius: int = 20,
        min_count: int | None = None,
        expected_template: str | None = None,
        expected_position: tuple[int, int] | None = None,
        position_tolerance: int = 30,
    ) -> None:
        if not templates:
            raise ValueError("MultiTemplateInspector cần ít nhất 1 template.")
        loaded: dict[str, np.ndarray] = {}
        for name, path in templates.items():
            tpl = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
            if tpl is None:
                raise FileNotFoundError(f"Không đọc được template '{name}': {path}")
            loaded[name] = tpl
        self._templates = loaded
        self._threshold = float(threshold)
        self._nms_radius = int(nms_radius)
        self._min_count = min_count
        self._expected_template = expected_template
        self._expected_position = expected_position
        self._position_tolerance = int(position_tolerance)

    def inspect(self, image: np.ndarray) -> InspectionReport:
        gray = _to_gray(image)
        ih, iw = gray.shape[:2]
        # 1) Match TỪNG template ở TẤT CẢ vị trí có score >= threshold.
        raw: list[tuple[int, int, float, str]] = []
        for name, tpl in self._templates.items():
            th, tw = tpl.shape[:2]
            if ih < th or iw < tw:
                continue
            for x, y, score in _find_all_matches(gray, tpl, self._threshold):
                raw.append((x, y, score, name))
        # 2) Non-Max Suppression: loại các match chồng lấn (cùng vật thể).
        kept = _nms(raw, self._nms_radius)
        # 3) Best match (score cao nhất) — dùng cho classify / position check.
        best = max(kept, key=lambda m: m[2]) if kept else None
        passed, detail = _evaluate_match(
            kept=kept,
            best=best,
            threshold=self._threshold,
            min_count=self._min_count,
            expected_template=self._expected_template,
            expected_position=self._expected_position,
            position_tolerance=self._position_tolerance,
        )
        score = best[2] if best else 0.0
        return InspectionReport(
            results=(
                InspectionResult(
                    name=self.name,
                    passed=passed,
                    score=score,
                    detail=detail,
                ),
            )
        )


def _find_all_matches(
    gray: np.ndarray, template: np.ndarray, threshold: float
) -> list[tuple[int, int, float]]:
    """Trả list (x, y, score) cho MỌI vị trí trong gray có score >= threshold."""
    result = cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED)
    ys, xs = np.where(result >= threshold)
    return [(int(x), int(y), float(result[y, x])) for x, y in zip(xs, ys)]


def _nms(
    matches: list[tuple[int, int, float, str]], radius: int
) -> list[tuple[int, int, float, str]]:
    """Greedy Non-Max Suppression: sort theo score giảm dần, giữ match cách
    match đã giữ ≥ radius pixel trên cả 2 trục."""
    sorted_m = sorted(matches, key=lambda m: -m[2])
    kept: list[tuple[int, int, float, str]] = []
    for x, y, score, name in sorted_m:
        if not any(
            abs(x - k[0]) < radius and abs(y - k[1]) < radius for k in kept
        ):
            kept.append((x, y, score, name))
    return kept


def _evaluate_match(
    kept: list[tuple[int, int, float, str]],
    best: tuple[int, int, float, str] | None,
    threshold: float,
    min_count: int | None,
    expected_template: str | None,
    expected_position: tuple[int, int] | None,
    position_tolerance: int,
) -> tuple[bool, str]:
    """Check đồng thời các tiêu chí (count / classify / position). AND tất cả."""
    if best is None:
        return False, f"count=0 threshold={threshold} (no match)"
    if min_count is not None and len(kept) < min_count:
        return False, f"count={len(kept)} cần >= {min_count}"
    if expected_template is not None and best[3] != expected_template:
        return False, f"best='{best[3]}' không phải '{expected_template}'"
    if expected_position is not None:
        ex, ey = expected_position
        dx, dy = best[0] - ex, best[1] - ey
        if abs(dx) > position_tolerance or abs(dy) > position_tolerance:
            return False, (
                f"best ở ({best[0]},{best[1]}) lệch ({dx:+d},{dy:+d}) "
                f"> tolerance {position_tolerance}"
            )
    # PASS — format chi tiết (cap 6 match để log không quá dài).
    pos = " ".join(f"({x},{y},{n},{s:.2f})" for x, y, s, n in kept[:6])
    more = f" +{len(kept) - 6}" if len(kept) > 6 else ""
    return True, (
        f"count={len(kept)} best=({best[0]},{best[1]},{best[3]},{best[2]:.3f}) "
        f"matches=[{pos}{more}]"
    )
