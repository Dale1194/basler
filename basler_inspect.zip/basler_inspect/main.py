"""Basler inspection - CLI entry point.

Workflow:
  1) (Một lần) Chụp ảnh mẫu chuẩn:
       python main.py --capture-reference
     → Lưu thành reference.png, copy path vào config.json.

  2) Chạy inspection:
       python main.py --once          # chụp 1 lần rồi thoát
       python main.py --interval 0.5  # chụp liên tục mỗi 0.5s
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

from camera import BaslerCamera
from inspector import InspectionReport, build_inspector


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Basler camera: chụp ảnh, kiểm tra pass/fail, lưu kết quả."
    )
    parser.add_argument("--config", type=Path, default=Path("config.json"),
                        help="File cấu hình (mặc định: config.json).")
    parser.add_argument("--once", action="store_true",
                        help="Chỉ chụp & kiểm tra 1 lần rồi thoát.")
    parser.add_argument("--interval", type=float, default=1.0,
                        help="Giây giữa 2 lần chụp khi chạy vòng lặp.")
    parser.add_argument("--capture-reference", action="store_true",
                        help="Chụp 1 ảnh, lưu làm golden sample rồi thoát.")
    parser.add_argument("--reference-out", type=Path, default=Path("reference.png"),
                        help="Đường dẫn lưu reference khi dùng --capture-reference.")
    parser.add_argument("--no-save", action="store_true",
                        help="Không lưu ảnh, chỉ in kết quả ra console.")
    return parser.parse_args()


def load_config(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def annotate(image: np.ndarray, report: InspectionReport) -> np.ndarray:
    """Vẽ label PASS/FAIL + chi tiết từng inspector lên ảnh (trả bản sao)."""
    out = image.copy()
    h, w = out.shape[:2]
    passed = report.passed
    label = "PASS" if passed else "FAIL"
    color = (0, 200, 0) if passed else (0, 0, 220)
    cv2.rectangle(out, (0, 0), (w, 50), (0, 0, 0), -1)
    cv2.putText(out, label, (10, 38), cv2.FONT_HERSHEY_SIMPLEX, 1.4, color, 2)
    y = 70
    for r in report.results:
        text = f"{r.name}: {'OK' if r.passed else 'FAIL'} ({r.detail})"
        cv2.putText(out, text, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        y += 22
    return out


def append_csv(path: Path, header: list[str], row: list[str]) -> None:
    """Append 1 row vào CSV; tự tạo header nếu file chưa có."""
    new_file = not path.exists()
    with path.open("a", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        if new_file:
            writer.writerow(header)
        writer.writerow(row)


def run_once(
    cam: BaslerCamera,
    inspector,
    output_dir: Path,
    csv_log: Path,
    save: bool,
    annotate_flag: bool,
    filename_prefix: str,
) -> None:
    image = cam.grab_one()
    report = inspector.inspect(image)
    passed = report.passed
    ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
    print(
        f"[{ts}] {'PASS' if passed else 'FAIL'} | "
        + " | ".join(f"{r.name}={r.score:.3f}" for r in report.results)
    )
    if save:
        out_img = annotate(image, report) if annotate_flag else image
        out = output_dir / f"{filename_prefix}_{ts}_{'PASS' if passed else 'FAIL'}.png"
        cv2.imwrite(str(out), out_img)
    append_csv(
        csv_log,
        header=["timestamp", "overall"] + [f"{r.name}_score" for r in report.results] + ["detail"],
        row=[
            ts,
            "PASS" if passed else "FAIL",
            *[f"{r.score:.4f}" for r in report.results],
            "; ".join(r.detail for r in report.results),
        ],
    )


def main() -> int:
    args = parse_args()
    config = load_config(args.config)

    serial = config["camera"].get("serial_number")

    if args.capture_reference:
        with BaslerCamera(serial_number=serial) as cam:
            cam.apply(config["camera"])
            image = cam.grab_one()
            cv2.imwrite(str(args.reference_out), image)
            print(f"Đã lưu reference: {args.reference_out}")
            print("Copy path này vào config.json -> inspection.reference_image.")
            return 0

    output_dir = ensure_dir(Path(config["capture"]["output_dir"]))
    csv_log = Path(config.get("logging", {}).get("csv_log", "results.csv"))
    save = not args.no_save
    annotate_flag = bool(config["capture"].get("annotate", True))
    prefix = str(config["capture"].get("filename_prefix", "img"))

    with BaslerCamera(serial_number=serial) as cam:
        cam.apply(config["camera"])
        inspector = build_inspector(config["inspection"])

        if args.once:
            run_once(cam, inspector, output_dir, csv_log, save, annotate_flag, prefix)
            return 0

        print(f"Chạy vòng lặp (Ctrl+C để dừng). Ảnh lưu tại: {output_dir}")
        try:
            while True:
                run_once(cam, inspector, output_dir, csv_log, save, annotate_flag, prefix)
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\nĐã dừng.")
            return 0


if __name__ == "__main__":
    sys.exit(main())
