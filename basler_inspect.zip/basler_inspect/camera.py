"""Basler camera wrapper sử dụng pypylon."""
from __future__ import annotations

from typing import Any

import numpy as np
from pypylon import pylon


class BaslerCamera:
    """Wrapper mỏng cho pypylon.InstantCamera, hỗ trợ context manager.

    Kết nối camera qua `connect()`, áp cấu hình qua `apply(settings)`,
    chụp 1 frame BGR numpy array qua `grab_one()`.
    """

    def __init__(self, serial_number: str | None = None) -> None:
        self._tl_factory = pylon.TlFactory.GetInstance()
        self._camera: pylon.InstantCamera | None = None
        self._serial = serial_number
        self._converter = pylon.ImageFormatConverter()
        self._converter.OutputPixelFormat = pylon.PixelType_BGR8packed
        self._converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

    def __enter__(self) -> BaslerCamera:
        self.connect()
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def connect(self) -> None:
        devices = self._tl_factory.EnumerateDevices()
        if not devices:
            raise RuntimeError("Không tìm thấy camera Basler nào trên hệ thống.")
        target: pylon.DeviceInfo | None = None
        if self._serial:
            for dev in devices:
                if dev.GetSerialNumber() == self._serial:
                    target = dev
                    break
            if target is None:
                raise RuntimeError(f"Không tìm thấy camera với serial '{self._serial}'.")
        else:
            target = devices[0]
        self._camera = pylon.InstantCamera(self._tl_factory.CreateDevice(target))
        self._camera.Open()
        info = self._camera.DeviceInfo
        print(f"Đã kết nối: {info.GetModelName()} (serial={info.GetSerialNumber()})")

    def apply(self, settings: dict[str, Any]) -> None:
        """Áp cấu hình từ dict. Bỏ qua key không tồn tại trong camera."""
        if self._camera is None:
            raise RuntimeError("Camera chưa kết nối. Gọi connect() trước.")
        cam = self._camera
        if "width" in settings and "height" in settings:
            cam.Width.SetValue(int(settings["width"]))
            cam.Height.SetValue(int(settings["height"]))
        if "offset_x" in settings:
            cam.OffsetX.SetValue(int(settings["offset_x"]))
        if "offset_y" in settings:
            cam.OffsetY.SetValue(int(settings["offset_y"]))
        if "exposure_time_us" in settings:
            cam.ExposureTimeAbs.SetValue(float(settings["exposure_time_us"]))
        if "gain_db" in settings:
            cam.Gain.SetValue(float(settings["gain_db"]))
        if "frame_rate" in settings:
            cam.AcquisitionFrameRateAbs.SetValue(float(settings["frame_rate"]))
        if settings.get("reverse_x"):
            cam.ReverseX.SetValue(True)
        if settings.get("reverse_y"):
            cam.ReverseY.SetValue(True)

    def grab_one(self, timeout_ms: int = 5000) -> np.ndarray:
        """Chụp đúng 1 frame, trả về numpy array (H, W, 3) BGR uint8."""
        if self._camera is None:
            raise RuntimeError("Camera chưa kết nối. Gọi connect() trước.")
        cam = self._camera
        cam.StartGrabbingMax(1)
        grab = cam.RetrieveResult(timeout_ms, pylon.TimeoutHandling_ThrowException)
        try:
            if not grab.GrabSucceeded():
                raise RuntimeError(f"Grab thất bại: {grab.ErrorDescription}")
            converted = self._converter.Convert(grab)
            return converted.GetArray()
        finally:
            grab.Release()

    def close(self) -> None:
        if self._camera is not None and self._camera.IsOpen():
            self._camera.Close()
        self._camera = None
