%% ========================================================================
% plant_model.m
% Xay dung mo hinh toan hoc cho he truyen dong dien - ban truot tuyen tinh
%
% Mo hinh bao gom:
%   1. Phuong trinh dien cua dong co (armature)
%   2. Phuong trinh co (quy doi ve truc dong co)
%   3. Ham truyen tu voltage -> vi tri x
%   4. Mo hinh state-space
%   5. Phan tich cuc (pole-zero), Bode, dap ung buoc
%
% Luu y: Chay file param_calc.m truoc de co bien 'motor', 'screw', ...
% =========================================================================

clc; clear; close all;

% Load thong so da tinh toan
if ~exist('params.mat', 'file')
    error('Khong tim thay file params.mat. Hay chay param_calc.m truoc!');
end
load('params.mat');

fprintf('\n========================================================================\n');
fprintf('  XAY DUNG MO HINH HE TRUYEN DONG DIEN\n');
fprintf('========================================================================\n\n');

%% ====================== 1. PHUONG TRINH DIEN - CO ========================
fprintf('--- 1. PHUONG TRINH DIEN - CO ---\n\n');

% PHUONG TRINH DIEN (Kich tu DC, armature-controlled):
%   V_a(t) = Ra * i_a(t) + La * di_a/dt + Ke * omega_m(t)
%
% PHUONG TRINH CO (reflected to motor shaft):
%   J_total * d(omega_m)/dt + B_total * omega_m(t) = Kt * i_a(t) - T_load(t)
%
% Trong do:
%   V_a    : dien ap phan ung (V)
%   i_a    : dong dien phan ung (A)
%   omega_m: van toc goc truc dong co (rad/s)
%   T_load : mo men tai quy doi (Nm)
%
% Bien doi Laplace (dieu kien ban dau = 0):
%   V_a(s) = (Ra + La*s) * I_a(s) + Ke * Omega_m(s)
%   (J_total*s + B_total) * Omega_m(s) = Kt * I_a(s) - T_load(s)

fprintf('  Dien:  V_a(s) = (Ra + La*s) I_a(s) + Ke * Omega_m(s)\n');
fprintf('  Co:    (J_total*s + B_total) Omega_m(s) = Kt * I_a(s) - T_load(s)\n\n');

%% ====================== 2. HAM TRUYEN DONG CO ---------------------------
fprintf('--- 2. HAM TRUYEN DONG CO ---\n\n');

% Tu 2 phuong trinh, loai bo I_a(s):
% I_a(s) = (J_total*s + B_total)/Kt * Omega_m(s) + T_load(s)/Kt
% Thay vao phuong trinh dien:
% V_a(s) = (Ra + La*s) * [(J_total*s + B_total)/Kt * Omega_m(s) + T_load(s)/Kt] + Ke*Omega_m(s)
%
% V_a(s) = [(Ra + La*s)(J_total*s + B_total) + Ke*Kt]/Kt * Omega_m(s) + (Ra + La*s)/Kt * T_load(s)
%
% Vi La rat nho (0.5 mH), co the bo qua La trong phuong trinh dien:
% V_a(s) ~= [Ra*(J_total*s + B_total) + Ke*Kt]/Kt * Omega_m(s) + Ra/Kt * T_load(s)

% === Ham truyen mo hinh don gian hoa (bo qua La) ===
% Omega(s)/V_a(s) = Kt / [Ra*J_total*s + (Ra*B_total + Ke*Kt)]

num_omega_simple = motor.Kt;
den_omega_simple = [motor.Ra * J_total, (motor.Ra * B_total + motor.Ke * motor.Kt)];
G_omega_simple = tf(num_omega_simple, den_omega_simple);

fprintf('  Mo hinh don gian hoa (bo qua La):\n');
fprintf('  Omega_m(s)/V_a(s) = %.4f / [%.4e s + %.4e]\n', ...
    num_omega_simple, den_omega_simple(1), den_omega_simple(2));
fprintf('  = %.3f / [%.4f s + 1]   (chuan hoa)\n\n', ...
    num_omega_simple/den_omega_simple(2), den_omega_simple(1)/den_omega_simple(2));

% === Ham truyen mo hinh day du (co La) ===
num_omega_full = motor.Kt;
den_omega_full = [motor.La * J_total, ...
                  (motor.Ra * J_total + motor.La * B_total), ...
                  (motor.Ra * B_total + motor.Ke * motor.Kt)];
G_omega_full = tf(num_omega_full, den_omega_full);

fprintf('  Mo hinh day du (ghi La):\n');
fprintf('  Omega_m(s)/V_a(s) = %.4f / [%.4e s^2 + %.4e s + %.4e]\n\n', ...
    num_omega_full, den_omega_full(1), den_omega_full(2), den_omega_full(3));

% So sanh 2 mo hinh
fprintf('  So sanh 2 mo hinh (vi La rat nho, nen gan nhu trung nhau):\n');
[mag1, phase1] = bode(G_omega_simple, [1, 10, 100, 1000, 10000]);
[mag2, phase2] = bode(G_omega_full, [1, 10, 100, 1000, 10000]);
fprintf('  | Don gian hoa | Day du  | Sai so |\n');
for k = 1:length(mag1)
    fprintf('  | %.3e    | %.3e | %.1f%% |\n', ...
        mag1(k), mag2(k), abs(mag1(k)-mag2(k))/mag1(k)*100);
end
fprintf('\n');

%% ====================== 3. HAM TRUYEN TU VOLTAGE -> POSITION ===========
fprintf('--- 3. HAM TRUYEN TU VOLTAGE SANG VI TRI ---\n\n');

% Vi tri tuyen tinh: x_l = K_conv * theta_m  (theta_m = vi tri goc)
% Trong mien Laplace: X_l(s) = K_conv * Omega_m(s) / s

% Su dung mo hinh don gian hoa de tiep tuc phan tich
G_position = K_conv * G_omega_simple / tf([1 0]);

fprintf('  P(s) = X_l(s)/V_a(s) = K_conv * Omega_m(s) / s\n');
fprintf('       = (%.4f) / [s*(%.4f s + 1)]\n', ...
    K_conv * motor.Kt / (motor.Ra*B_total + motor.Ke*motor.Kt), ...
    motor.Ra * J_total / (motor.Ra*B_total + motor.Ke*motor.Kt));

% He so cuoi cung:
K_final = K_conv * motor.Kt / (motor.Ra * B_total + motor.Ke * motor.Kt);
tau_final = motor.Ra * J_total / (motor.Ra * B_total + motor.Ke * motor.Kt);

fprintf('  => P(s) = %.4f / [s*(%.4f s + 1)]\n', K_final, tau_final);
fprintf('  (he so K_position = %.4f m/(V.s), hang so thoi gian tau_v = %.4f ms)\n\n', ...
    K_final, tau_final*1000);

%% ====================== 4. PHAN TICH CUC (POLE-ZERO) ====================
fprintf('--- 4. PHAN TICH CUC (POLE-ZERO) ---\n\n');

figure('Name', 'Pole-Zero Map', 'Position', [100 200 600 500]);
pzmap(G_position);
grid on;
title('Pole-Zero Map cua P(s) = X(s)/V_a(s)');

% In cac cuc zero
poles = pole(G_position);
zeros_pz = zero(G_position);
fprintf('  Cuc (Poles):\n');
for k = 1:length(poles)
    fprintf('    p%d = %.4f %+.4fj\n', k, real(poles(k)), imag(poles(k)));
end
fprintf('  Zero: khong co\n\n');

% Phan tich he so
fprintf('  He so GIAI THUA (decay rate): sigma = 1/tau_v = %.1f 1/s\n', 1/tau_final);
fprintf('  Cuc tai 0 (integrator) cho thay day la he Type 1\n');
fprintf('  --> Step input: sai so vi tri tai = 0 (SSE = 0)\n\n');

%% ====================== 5. DAP UNG BUOC OPEN-LOOP ======================
fprintf('--- 5. DAP UNG BUOC OPEN-LOOP ---\n\n');

% Step response voi V_a = 1V (don vi)
figure('Name', 'Open-Loop Step Response', 'Position', [100 700 800 400]);
[y_step, t_step] = step(G_position, 5);  % simulate 5 seconds
plot(t_step*1000, y_step*1000, 'b', 'LineWidth', 2);
grid on;
xlabel('Thoi gian (ms)');
ylabel('Vi tri x(t) (mm)');
title('Dap ung buoc open-loop: V_a = 1V (1 step input)');
% Luu y: Vi he Type 1, position ramp tang tuyen tinh (khong dat on dinh)

% Them mot step 24V (dien ap toi da) de xem toc do ramp
y_step24 = step(G_position * 24, t_step);
figure('Name', 'Open-Loop 24V', 'Position', [950 700 800 400]);
plot(t_step, y_step24*1000, 'b', 'LineWidth', 2);
grid on;
xlabel('Thoi gian (s)');
ylabel('Vi tri x(t) (mm)');
title('Dap ung buoc open-loop: V_a = 24V');
hold on;
yline(300, 'r--', 'Hanh trinh 300 mm', 'LineWidth', 1.5);

fprintf('  Vi he Type 1 (co integrator), voi input hang so, position tang tuyen tinh.\n');
fprintf('  Van toc on dinh: v_ss = 24V * K_position = %.3f m/s\n', 24*K_final);
fprintf('  (Vuot qua yeu cau 0.2 m/s)\n\n');

%% ====================== 6. BODE PLOT ====================================
fprintf('--- 6. BODE PLOT ---\n\n');

figure('Name', 'Bode Plot', 'Position', [100 100 900 600]);
bode(G_position, {0.1, 1000});
grid on;
title('Bode Plot P(s) = X(s)/V_a(s)');

[Gm, Pm, Wcg, Wcp] = margin(G_position*K_final*100);  % voi gain K=100 de xem
fprintf('  Phan tich tuyen tinh hoa:\n');
fprintf('  - Do tre (transport lag): 0 (he khong co pure delay)\n');
fprintf('  - He so cua integrator: 1/s, nen he Type 1\n');
fprintf('  - Tai tan so thap: |G| giam -20 dB/dec\n');
fprintf('  - Tai tan so cao (>1/tau_v): |G| giam -40 dB/dec\n\n');

%% ====================== 7. MO HINH STATE-SPACE =========================
fprintf('--- 7. MO HINH STATE-SPACE ---\n\n');

% Chon state variables:
%   x1 = omega_m (van toc goc, rad/s)
%   x2 = theta_m (vi tri goc, rad)
%   x3 = i_a (dong dien, A)  -- them neu mo hinh day du co La
%
% Mo hinh don gian hoa (bo qua La): 2 states
%   dx1/dt = -(B_total/J_total)*x1 + (Kt/J_total)*u
%   dx2/dt = x1
%   y = K_conv * x2  (vi tri tuyen tinh)

A_simple = [-B_total/J_total, 0;
             1,             0];
B_simple = [motor.Kt/J_total; 0];
C_simple = [0, K_conv];
D_simple = 0;

sys_simple = ss(A_simple, B_simple, C_simple, D_simple);
sys_simple.InputName = 'V_a';
sys_simple.OutputName = 'x_l';
sys_simple.StateName = {'omega_m', 'theta_m'};

fprintf('  State-space (mo hinh don gian hoa):\n');
fprintf('  dx1/dt (omega_m) = %.2f * x1 + %.0f * V_a\n', A_simple(1,1), B_simple(1));
fprintf('  dx2/dt (theta_m) = x1\n');
fprintf('  y (x_l) = %.4f * theta_m\n\n', K_conv);

% Mo hinh day du (co La): 3 states
%   dx1/dt = -Ra/La * x1 - Ke/La * x2 + 1/La * V_a   (i_a)
%   dx2/dt = Kt/J_total * x1 - B_total/J_total * x2  (omega_m)
%   dx3/dt = x2                                       (theta_m)
%   y = K_conv * x3

A_full = [-motor.Ra/motor.La, -motor.Ke/motor.La, 0;
           motor.Kt/J_total,   -B_total/J_total,   0;
           0,                   1,                  0];
B_full = [1/motor.La; 0; 0];
C_full = [0, 0, K_conv];
D_full = 0;

sys_full = ss(A_full, B_full, C_full, D_full);

fprintf('  State-space (mo hinh day du):\n');
fprintf('  dx1/dt = %.0f*x1 %.0f*x2 + %.0f*V_a\n', A_full(1,1), A_full(1,2), B_full(1));
fprintf('  dx2/dt = %.0f*x1 + %.0f*x2\n', A_full(2,1), A_full(2,2));
fprintf('  dx3/dt = x2\n');
fprintf('  y = %.4f*x3\n\n', K_conv);

%% ====================== 8. XAC NHAN MO HINH ============================
fprintf('--- 8. XAC NHAN MO HINH ---\n\n');

% So sanh tf va ss phai cho cung dap ung
figure('Name', 'Verify Model', 'Position', [100 1300 800 400]);
step(G_position, sys_simple, 2);
legend('Transfer Function', 'State-Space', 'Location', 'Best');
title('Xac nhan: TF va State-Space cho cung dap ung');
grid on;

fprintf('  Da xac nhan tf va ss cho cung dap ung.\n\n');

% Luu mo hinh vao file
save('plant.mat', 'G_omega_simple', 'G_omega_full', 'G_position', ...
     'sys_simple', 'sys_full', 'A_simple', 'B_simple', 'C_simple', 'D_simple', ...
     'A_full', 'B_full', 'C_full', 'D_full', 'K_final', 'tau_final');

fprintf('  >> Da luu mo hinh vao file: plant.mat\n');
fprintf('  >> Su dung file: pid_design.m\n\n');
