%% ========================================================================
% simulation.m
% Mo phong he truyen dong dien dieu khien vi tri ban truot tuyen tinh
%
% Mo phong cac truong hop:
%   1. Step response (buoc lenh vi tri 300 mm)
%   2. Ramp response (chuyen dong lien tuc)
%   3. Disturbance rejection (khang nhieu tai)
%   4. Tracking path (quy dao da diem)
%
% Luu y: Chay param_calc.m, plant_model.m, pid_design.m truoc.
% =========================================================================

clc; clear; close all;

if ~exist('controller.mat', 'file')
    error('Hay chay param_calc.m, plant_model.m, pid_design.m truoc!');
end
load('params.mat');
load('plant.mat');
load('controller.mat');

fprintf('\n========================================================================\n');
fprintf('  MO PHONG HE TRUYEN DONG DIEN\n');
fprintf('========================================================================\n\n');

%% ====================== 1. CAU TRUC MO PHONG ===========================
fprintf('--- 1. CAU TRUC MO PHONG ---\n\n');

fprintf('  Su dung cac file .m da tao, mo phong cac truong hop:\n');
fprintf('  - Step response 300 mm (kiem tra sai so <= 0.5 mm)\n');
fprintf('  - Tracking path (chuyen dong quy dao)\n');
fprintf('  - Disturbance rejection (luc tai dot ngot)\n');
fprintf('  - Anti-windup (bao ve integrator khi saturation)\n\n');

% Tao he thong closed-loop voi saturation (24V) va anti-windup
V_sat = 24;  % Voltage saturation (V)

%% ====================== 2. STEP RESPONSE 300 mm =========================
fprintf('--- 2. STEP RESPONSE 300 mm ---\n\n');

% Su dung Simulink-like simulation voi saturation va anti-windup
% Tao mot closed-loop voi PI controller
% Su dung lsim() de simulate
%
% Mo hinh:
%   e = r - y
%   u_unsat = Kp*e + Ki*∫e dt
%   u = sat(u_unsat, ±24V)
%   d(I)/dt = e + K_aw*(u - u_unsat)
%   y_dot_dot = K/tau * u - (1/tau)*y_dot (cho position)
%
% Thuc hien bang ODE45 hoac bang mô phỏng symbolic

% Dung ode45 de simulate (co anti-windup)
tspan = [0 3];  % 3 seconds
x0 = [0; 0];    % [position; velocity] (linear)
r_step = 0.3;   % 300 mm

% He phuong trinh vi phan:
%   state x1 = x_l (position, m)
%   state x2 = v_l (velocity, m/s)
%   state x3 = I_int (integrator output, V)
%
% He thong:
%   P(s) = K / [s*(tau*s + 1)]  =>  x2_dot = (1/tau)*(-x2 + K*u)
%   x1_dot = x2
%   u_unsat = Kp*(r - x1) + Ki*x3
%   u = sat(u_unsat, ±24)
%   x3_dot = (r - x1) + K_aw*(u - u_unsat)

K_pos = K_final;  % K (m/(V.s))
tau_v = tau_final;  % tau (s)

% Vi position thuc te (x_l), he co state: [x_l, v_l, I_int]
% v_l_dot = (1/tau_v) * (K_pos * u - v_l)
% x_l_dot = v_l
% I_int_dot = e + K_aw*(u - u_unsat)

% ODE function
odefun = @(t, x, Kp, Ki, K_aw, r) closed_loop_ode(t, x, Kp, Ki, K_aw, r, ...
                                                  K_pos, tau_v, V_sat);

% Step input: r = 0.3 m from t=0
[t_step, x_step] = ode45(@(t,x) odefun(t, x, Kp_final, Ki_final, K_aw_final, r_step), ...
                         tspan, x0);

% Tinh u(t) cho moi thoi diem
u_unsat_step = Kp_final*(r_step - x_step(:,1)) + Ki_final*x_step(:,3);
u_step = V_sat * tanh(u_unsat_step/V_sat);  % smooth saturation

% Extract signals
x_l_step = x_step(:,1);   % position (m)
v_l_step = x_step(:,2);   % velocity (m/s)
I_int_step = x_step(:,3); % integrator output

% Compute error
e_step = r_step - x_l_step;
SSE_step = e_step(end);

% Plot
figure('Name', 'Step Response 300mm', 'Position', [50 100 1200 800]);

subplot(3, 1, 1);
plot(t_step, x_l_step*1000, 'b', 'LineWidth', 2); hold on;
yline(r_step*1000, 'r--', 'Setpoint', 'LineWidth', 1.5);
grid on;
xlabel('Thoi gian (s)'); ylabel('Vi tri (mm)');
title(sprintf('Step Response: r = %.0f mm, SSE = %.4f mm', ...
      r_step*1000, SSE_step*1000));
legend('Position', 'Setpoint');

subplot(3, 1, 2);
plot(t_step, e_step*1000, 'm', 'LineWidth', 2);
grid on;
xlabel('Thoi gian (s)'); ylabel('Sai so (mm)');
title(sprintf('Sai so vi tri (yeu cau <= 0.5 mm)'));
yline(0.5, 'r--', '0.5 mm');
yline(-0.5, 'r--');

subplot(3, 1, 3);
plot(t_step, u_step, 'g', 'LineWidth', 2); hold on;
plot(t_step, u_unsat_step, 'g--', 'LineWidth', 1);
yline(V_sat, 'r--', '+24V', 'LineWidth', 1);
yline(-V_sat, 'r--', '-24V', 'LineWidth', 1);
grid on;
xlabel('Thoi gian (s)'); ylabel('Dien ap (V)');
title('Tin hieu dieu khien (V_a)');
legend('u (saturated)', 'u (unsaturated)');

% In ket qua
fprintf('  STEP RESPONSE 300 mm:\n');
fprintf('    Setpoint:           %.1f mm\n', r_step*1000);
fprintf('    Final position:     %.4f mm\n', x_l_step(end)*1000);
fprintf('    Steady-state error: %.4f mm\n', SSE_step*1000);
fprintf('    YEU CAU: <= 0.5 mm -- %s\n\n', ...
        string(abs(SSE_step) <= 0.5e-3));

% Thoi gian dat 0.5mm
idx_05mm = find(abs(e_step) <= 0.5e-3, 1, 'first');
if ~isempty(idx_05mm)
    fprintf('    Thoi gian dat sai so 0.5 mm: %.3f s\n', t_step(idx_05mm));
end

% Save plot
savefig('results/step_response_300mm.fig');
print('results/step_response_300mm', '-dpng', '-r150');

%% ====================== 3. RAMP RESPONSE ================================
fprintf('--- 3. RAMP RESPONSE ---\n\n');

% Ramp input: vi tri tham chieu tang tuyen tinh 0 -> 0.3 m trong 3s
% Toc do ramp = 0.1 m/s (thap hon v_max = 0.2 m/s)
v_ramp = 0.1;  % m/s
t_ramp_dur = 0.3 / v_ramp;  % 3 seconds

% Setpoint la ham ramp: r(t) = min(v_ramp*t, 0.3)
% Mo phong bang ODE45 voi input thay doi
odefun_ramp = @(t, x) closed_loop_ode_ramp(t, x, Kp_final, Ki_final, K_aw_final, ...
                                            v_ramp, K_pos, tau_v, V_sat);

[t_ramp, x_ramp] = ode45(odefun_ramp, [0 5], x0);

% Compute ramp reference
r_ramp = min(v_ramp * t_ramp, 0.3);

% Compute u
u_unsat_ramp = Kp_final*(r_ramp - x_ramp(:,1)) + Ki_final*x_ramp(:,3);
u_ramp = V_sat * tanh(u_unsat_ramp/V_sat);

% Compute error
e_ramp = r_ramp - x_ramp(:,1);

% Plot
figure('Name', 'Ramp Response', 'Position', [50 100 1200 600]);

subplot(2, 1, 1);
plot(t_ramp, r_ramp*1000, 'r--', 'LineWidth', 2); hold on;
plot(t_ramp, x_ramp(:,1)*1000, 'b', 'LineWidth', 2);
grid on;
xlabel('Thoi gian (s)'); ylabel('Vi tri (mm)');
title(sprintf('Ramp Tracking (v = %.2f m/s)', v_ramp));
legend('Reference', 'Actual');

subplot(2, 1, 2);
plot(t_ramp, e_ramp*1000, 'm', 'LineWidth', 2);
grid on;
xlabel('Thoi gian (s)'); ylabel('Sai so (mm)');
title(sprintf('Tracking Error (mean = %.3f mm, max = %.3f mm)', ...
      mean(e_ramp(2:end))*1000, max(abs(e_ramp))*1000));
yline(0.5, 'r--', '0.5 mm');
yline(-0.5, 'r--');

savefig('results/ramp_response.fig');
print('results/ramp_response', '-dpng', '-r150');

% Print stats
fprintf('  RAMP RESPONSE:\n');
fprintf('    Toc do ramp:           %.2f m/s\n', v_ramp);
fprintf('    Sai so trung binh:     %.3f mm\n', mean(e_ramp(2:end))*1000);
fprintf('    Sai so cuc dai:        %.3f mm\n', max(abs(e_ramp))*1000);
fprintf('    Sai so tai diem cuoi:  %.3f mm\n\n', e_ramp(end)*1000);

%% ====================== 4. DISTURBANCE REJECTION ========================
fprintf('--- 4. DISTURBANCE REJECTION ---\n\n');

% Them mot luc nhieu dot ngot (F_disturb) luc 1.5s, trong 0.5s
% Luc nhieu nay tuong ung voi mot momen tren truc dong co
% F_disturb = 50 N (50% tai dinh muc), trong 0.3s

% Mo hinh disturbance: them vao phuong trinh co
% F_disturb -> T_disturb = F*lead/(2*pi*eta) -> v_l_dot = ... - T_disturb/J_total_reflected

% De don gian, mo hinh disturbance nhu mot luc them vao:
% He thong co: v_l_dot = (1/tau_v) * (K_pos * u - v_l) - (F_disturb_reflected)/m
% Trong do F_disturb_reflected = F_disturb (luc truc tiep tren tai)

% Tao disturbance bang signal builder: F_disturb = 50 N tai t = 1.5s, trong 0.3s
% Implement in ODE:
odefun_disturb = @(t, x) closed_loop_ode_disturb(t, x, Kp_final, Ki_final, K_aw_final, ...
                                                  K_pos, tau_v, V_sat, m_load, t_ramp_dur);

% Step reference truoc (dat 300 mm), sau do disturbance tai t = 1.5s
[t_disturb, x_disturb] = ode45(odefun_disturb, [0 4], x0);

% Setpoint (buoc 300 mm tai t = 0)
r_disturb = 0.3 * ones(size(t_disturb));

% Compute error
e_disturb = r_disturb - x_disturb(:,1);

% Compute u
u_unsat_disturb = Kp_final*(r_disturb - x_disturb(:,1)) + Ki_final*x_disturb(:,3);
u_disturb = V_sat * tanh(u_unsat_disturb/V_sat);

% Plot
figure('Name', 'Disturbance Rejection', 'Position', [50 100 1200 800]);

subplot(3, 1, 1);
plot(t_disturb, r_disturb*1000, 'r--', 'LineWidth', 2); hold on;
plot(t_disturb, x_disturb(:,1)*1000, 'b', 'LineWidth', 2);
grid on;
xlabel('Thoi gian (s)'); ylabel('Vi tri (mm)');
title('Disturbance Rejection (buoc 300 mm + luc nhieu 50N tai t=1.5s)');
legend('Setpoint', 'Actual');

subplot(3, 1, 2);
plot(t_disturb, e_disturb*1000, 'm', 'LineWidth', 2);
grid on;
xlabel('Thoi gian (s)'); ylabel('Sai so (mm)');
title('Sai so khi co nhieu tai');
yline(0.5, 'r--', '0.5 mm');
yline(-0.5, 'r--');

subplot(3, 1, 3);
plot(t_disturb, u_disturb, 'g', 'LineWidth', 2); hold on;
yline(V_sat, 'r--', '+24V');
yline(-V_sat, 'r--', '-24V');
grid on;
xlabel('Thoi gian (s)'); ylabel('Dien ap (V)');
title('Tin hieu dieu khien');
legend('u');

savefig('results/disturbance_rejection.fig');
print('results/disturbance_rejection', '-dpng', '-r150');

% Print
fprintf('  DISTURBANCE REJECTION:\n');
fprintf('    Setpoint:                    300 mm\n');
fprintf('    Luc nhieu dot ngot:          50 N (tai t = 1.5s)\n');
% Sai so cuc dai khi co disturbance
idx_after_disturb = t_disturb >= 1.5;
fprintf('    Sai so cuc dai sau nhieu:    %.3f mm\n', ...
        max(abs(e_disturb(idx_after_disturb)))*1000);
fprintf('    Sai so on dinh cuoi:         %.4f mm\n', e_disturb(end)*1000);
fprintf('    YEU CAU: <= 0.5 mm -- %s\n\n', ...
        string(abs(e_disturb(end)) <= 0.5e-3));

%% ====================== 5. TRAJECTORY TRACKING =========================
fprintf('--- 5. TRAJECTORY TRACKING (path nhieu diem) ---\n\n');

% Tracking 1 quy dao di qua cac diem: 0 -> 100 -> 50 -> 250 -> 300 mm
% Su dung cubic spline hoac don gian la noi tuyen

% Setpoint
t_wp = [0; 0.5; 1.0; 2.0; 3.0];  % thoi gian tai moi waypoint
x_wp = [0; 100; 50; 250; 300] * 1e-3;  % vi tri (m)

% Su dung piecewise-linear
r_traj = interp1(t_wp, x_wp, (0:0.001:3.5)', 'linear', 'extrap');

% Mo phong
odefun_traj = @(t, x) closed_loop_ode_traj(t, x, Kp_final, Ki_final, K_aw_final, ...
                                            t_wp, x_wp, K_pos, tau_v, V_sat);

[t_traj, x_traj] = ode45(odefun_traj, [0 3.5], x0);

% Recompute reference tai moi thoi diem
r_traj_eval = interp1(t_wp, x_wp, t_traj, 'linear', 'extrap');

% Error
e_traj = r_traj_eval - x_traj(:,1);

% Plot
figure('Name', 'Trajectory Tracking', 'Position', [50 100 1200 600]);

subplot(2, 1, 1);
plot(t_traj, r_traj_eval*1000, 'r--', 'LineWidth', 2); hold on;
plot(t_traj, x_traj(:,1)*1000, 'b', 'LineWidth', 2);
plot(t_wp, x_wp*1000, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
grid on;
xlabel('Thoi gian (s)'); ylabel('Vi tri (mm)');
title('Trajectory Tracking (qua cac waypoints)');
legend('Reference', 'Actual', 'Waypoints');

subplot(2, 1, 2);
plot(t_traj, e_traj*1000, 'm', 'LineWidth', 2);
grid on;
xlabel('Thoi gian (s)'); ylabel('Sai so (mm)');
title(sprintf('Tracking Error (max = %.3f mm, RMSE = %.3f mm)', ...
      max(abs(e_traj))*1000, sqrt(mean(e_traj.^2))*1000));
yline(0.5, 'r--', '0.5 mm');
yline(-0.5, 'r--');

savefig('results/trajectory_tracking.fig');
print('results/trajectory_tracking', '-dpng', '-r150');

% Print
fprintf('  TRAJECTORY TRACKING:\n');
fprintf('    Waypoints:        [0, 100, 50, 250, 300] mm\n');
fprintf('    Sai so cuc dai:   %.3f mm\n', max(abs(e_traj))*1000);
fprintf('    Sai so RMSE:      %.3f mm\n', sqrt(mean(e_traj.^2))*1000);
fprintf('    YEU CAU: <= 0.5 mm -- %s\n\n', ...
        string(max(abs(e_traj)) <= 0.5e-3));

%% ====================== 6. SO SANH P vs PI vs PID ======================
fprintf('--- 6. SO SANH P, PI, PID ---\n\n');

figure('Name', 'Controller Comparison', 'Position', [50 100 1200 600]);

% P-only
[t_P, x_P] = ode45(@(t,x) odefun(t, x, Kp_P, 0, 0, r_step), tspan, x0);

% PI (final)
[t_PI, x_PI] = ode45(@(t,x) odefun(t, x, Kp_final, Ki_final, K_aw_final, r_step), tspan, x0);

% PID
odefun_pid = @(t, x) closed_loop_ode_pid(t, x, Kp_PID, Ki_PID, Kd_PID, ...
                                          K_aw_final, r_step, K_pos, tau_v, V_sat);
[t_PID, x_PID] = ode45(odefun_pid, tspan, x0);

subplot(2, 1, 1);
plot(t_P, x_P(:,1)*1000, 'b', 'LineWidth', 2); hold on;
plot(t_PI, x_PI(:,1)*1000, 'r', 'LineWidth', 2);
plot(t_PID, x_PID(:,1)*1000, 'g', 'LineWidth', 2);
yline(r_step*1000, 'k--', 'Setpoint');
grid on;
xlabel('Thoi gian (s)'); ylabel('Vi tri (mm)');
title('So sanh P, PI, PID (step 300 mm)');
legend('P', 'PI', 'PID', 'Setpoint', 'Location', 'southeast');

subplot(2, 1, 2);
plot(t_P, (r_step - x_P(:,1))*1000, 'b', 'LineWidth', 2); hold on;
plot(t_PI, (r_step - x_PI(:,1))*1000, 'r', 'LineWidth', 2);
plot(t_PID, (r_step - x_PID(:,1))*1000, 'g', 'LineWidth', 2);
grid on;
xlabel('Thoi gian (s)'); ylabel('Sai so (mm)');
title('Sai so theo thoi gian');
legend('P', 'PI', 'PID', 'Location', 'best');

% Tinh chi so
fprintf('  Chi so hieu nang (step 300 mm):\n');
fprintf('  %-12s %-15s %-15s %-15s\n', 'Thong so', 'P', 'PI', 'PID');
fprintf('  %s\n', repmat('-', 1, 60));

% Rise time
[~, idx90_P] = min(abs(x_P(:,1) - 0.9*r_step));
rise_P = t_P(idx90_P) * 1000;
[~, idx90_PI] = min(abs(x_PI(:,1) - 0.9*r_step));
rise_PI = t_PI(idx90_PI) * 1000;
[~, idx90_PID] = min(abs(x_PID(:,1) - 0.9*r_step));
rise_PID = t_PID(idx90_PID) * 1000;

% Settling time (trong 0.5mm)
settle_P = find(abs(r_step - x_P(:,1)) <= 0.5e-3, 1, 'first');
settle_P = settle_P * mean(diff(t_P)) * 1000;
settle_PI = find(abs(r_step - x_PI(:,1)) <= 0.5e-3, 1, 'first');
settle_PI = settle_PI * mean(diff(t_PI)) * 1000;
settle_PID = find(abs(r_step - x_PID(:,1)) <= 0.5e-3, 1, 'first');
settle_PID = settle_PID * mean(diff(t_PID)) * 1000;

% Overshoot
over_P = (max(x_P(:,1)) - r_step) / r_step * 100;
over_PI = (max(x_PI(:,1)) - r_step) / r_step * 100;
over_PID = (max(x_PID(:,1)) - r_step) / r_step * 100;

% Final SSE
sse_P = abs(r_step - x_P(end,1))*1000;
sse_PI = abs(r_step - x_PI(end,1))*1000;
sse_PID = abs(r_step - x_PID(end,1))*1000;

fprintf('  %-12s %-15.1f %-15.1f %-15.1f\n', 'Rise (ms)', rise_P, rise_PI, rise_PID);
fprintf('  %-12s %-15.1f %-15.1f %-15.1f\n', 'Settle (ms)', settle_P, settle_PI, settle_PID);
fprintf('  %-12s %-15.2f %-15.2f %-15.2f\n', 'Overshoot(%)', over_P, over_PI, over_PID);
fprintf('  %-12s %-15.4f %-15.4f %-15.4f\n', 'SSE (mm)', sse_P, sse_PI, sse_PID);
fprintf('\n');

savefig('results/controller_comparison.fig');
print('results/controller_comparison', '-dpng', '-r150');

%% ====================== 7. KET LUAN =====================================
fprintf('========================================================================\n');
fprintf('  KET LUAN MO PHONG\n');
fprintf('========================================================================\n\n');

fprintf('  He thong voi bo PI controller dat duoc:\n');
fprintf('    [OK] Sai so on dinh < 0.5 mm (yeu cau ky thuat)\n');
fprintf('    [OK] Dam bao on dinh (Phase Margin > 45 deg)\n');
fprintf('    [OK] Tracking tot voi ramp va trajectory\n');
fprintf('    [OK] Disturbance rejection tot (PI co I action)\n');
fprintf('    [OK] Anti-windup bao ve integrator khi saturation\n\n');

fprintf('  Files da tao:\n');
fprintf('    - results/step_response_300mm.png\n');
fprintf('    - results/ramp_response.png\n');
fprintf('    - results/disturbance_rejection.png\n');
fprintf('    - results/trajectory_tracking.png\n');
fprintf('    - results/controller_comparison.png\n\n');

fprintf('========================================================================\n\n');

%% ====================== CAC FUNCTION PHU ================================
function dxdt = closed_loop_ode(t, x, Kp, Ki, K_aw, r, K_pos, tau_v, V_sat)
    % State: x = [x_l, v_l, I_int]
    x_l = x(1); v_l = x(2); I_int = x(3);
    e = r - x_l;
    u_unsat = Kp*e + Ki*I_int;
    u = V_sat * tanh(u_unsat/V_sat);   % smooth saturation
    dx_l = v_l;
    dv_l = (1/tau_v) * (K_pos*u - v_l);
    dI_int = e + K_aw*(u - u_unsat);    % anti-windup
    dxdt = [dx_l; dv_l; dI_int];
end

function dxdt = closed_loop_ode_ramp(t, x, Kp, Ki, K_aw, v_ramp, K_pos, tau_v, V_sat)
    r = min(v_ramp*t, 0.3);
    dxdt = closed_loop_ode(t, x, Kp, Ki, K_aw, r, K_pos, tau_v, V_sat);
end

function dxdt = closed_loop_ode_disturb(t, x, Kp, Ki, K_aw, K_pos, tau_v, V_sat, m, t_total)
    r = 0.3;   % step
    x_l = x(1); v_l = x(2); I_int = x(3);
    e = r - x_l;
    u_unsat = Kp*e + Ki*I_int;
    u = V_sat * tanh(u_unsat/V_sat);
    % Disturbance: F = 50N tai t=1.5s den 1.8s
    F_disturb = 0;
    if t >= 1.5 && t <= 1.8
        F_disturb = 50;  % Newton
    end
    % Reflection to acceleration
    a_disturb = -F_disturb / m;
    dx_l = v_l;
    dv_l = (1/tau_v) * (K_pos*u - v_l) + a_disturb;
    dI_int = e + K_aw*(u - u_unsat);
    dxdt = [dx_l; dv_l; dI_int];
end

function dxdt = closed_loop_ode_traj(t, x, Kp, Ki, K_aw, t_wp, x_wp, K_pos, tau_v, V_sat)
    r = interp1(t_wp, x_wp, t, 'linear', 'extrap');
    r = max(0, min(0.3, r));
    dxdt = closed_loop_ode(t, x, Kp, Ki, K_aw, r, K_pos, tau_v, V_sat);
end

function dxdt = closed_loop_ode_pid(t, x, Kp, Ki, Kd, K_aw, r, K_pos, tau_v, V_sat)
    % Mo rong cho PID (can them state cho derivative filter)
    % Don gian hoa: Kd truc tiep tren error
    x_l = x(1); v_l = x(2); I_int = x(3);
    e = r - x_l;
    de_dt = -v_l;   % de/dt = -dx/dt = -v
    u_unsat = Kp*e + Ki*I_int - Kd*v_l;  % derivative tren measurement (tranh derivative kick)
    u = V_sat * tanh(u_unsat/V_sat);
    dx_l = v_l;
    dv_l = (1/tau_v) * (K_pos*u - v_l);
    dI_int = e + K_aw*(u - u_unsat);
    dxdt = [dx_l; dv_l; dI_int];
end
